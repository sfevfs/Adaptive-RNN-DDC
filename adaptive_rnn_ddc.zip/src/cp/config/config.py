from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Literal
import yaml
from src.utils.dirs import DIR_DATA, DIR_OUTPUTS

def _ensure_dict(x: Any) -> dict[str, Any]:
    if x is None:
        return {}
    if isinstance(x, dict):
        return x
    raise TypeError(f'Expected dict or None, got {type(x)}')

def _ensure_list(x: Any) -> list[Any]:
    if x is None:
        return []
    if isinstance(x, list):
        return x
    if isinstance(x, tuple):
        return list(x)
    return [x]

@dataclass
class DataConfig:
    dir_dataset: str = DIR_DATA
    batch_size: int = 16
    num_workers: int = 1
    is_U2D: bool = False
    shuffle: bool = True
    train_ratio: float = 0.9
    is_separate_antennas: bool = True
    return_metadata: bool = False
    add_noise_in_val: bool = True

    def __post_init__(self):
        self.dir_dataset = str(self.dir_dataset)
        self.batch_size = int(self.batch_size)
        self.num_workers = int(self.num_workers)
        self.is_U2D = bool(self.is_U2D)
        self.shuffle = bool(self.shuffle)
        self.train_ratio = float(self.train_ratio)
        self.is_separate_antennas = bool(self.is_separate_antennas)
        self.return_metadata = bool(self.return_metadata)
        self.add_noise_in_val = bool(self.add_noise_in_val)
        if self.batch_size <= 0:
            raise ValueError(f'batch_size must be positive, got {self.batch_size}')
        if self.num_workers < 0:
            raise ValueError(f'num_workers must be >= 0, got {self.num_workers}')
        if not 0.0 < self.train_ratio < 1.0:
            raise ValueError(f'train_ratio must be in (0,1), got {self.train_ratio}')

@dataclass
class ModelConfig:
    name: str = 'RNN_TDD'
    is_separate_antennas: bool = True
    params: dict[str, Any] = field(default_factory=dict)
    checkpoint_path: str | None = None

    def __post_init__(self):
        self.name = str(self.name)
        self.is_separate_antennas = bool(self.is_separate_antennas)
        self.params = _ensure_dict(self.params)
        self.checkpoint_path = None if self.checkpoint_path in (None, '', 'null', 'None') else str(self.checkpoint_path)
        if 'controller' in self.params:
            self.params['controller'] = _ensure_dict(self.params['controller'])
        if 'predictor' in self.params:
            self.params['predictor'] = _ensure_dict(self.params['predictor'])
        for key in ('low_hidden_dims', 'high_hidden_dims', 'full_hidden_dims', 'rate_values'):
            if key in self.params:
                self.params[key] = _ensure_list(self.params[key])
        for key in ('low_dim', 'high_dim', 'full_dim', 'gumbel_anneal_steps'):
            if key in self.params and self.params[key] is not None:
                self.params[key] = int(self.params[key])
        for key in ('target_avg_budget', 'peak_budget', 'qos_threshold', 'lambda_avg', 'lambda_peak', 'lambda_qos', 'lambda_ce', 'gumbel_tau_start', 'gumbel_tau_end', 'expert_dropout'):
            if key in self.params and self.params[key] is not None:
                self.params[key] = float(self.params[key])
        for key in ('expert_use_layernorm', 'hard_in_eval'):
            if key in self.params and self.params[key] is not None:
                self.params[key] = bool(self.params[key])

@dataclass
class TrainingConfig:
    num_epochs: int = 500
    gradient_clip_val: float | None = None
    accumulate_grad_batches: int = 1
    check_val_every_n_epoch: int = 1
    early_stopping: bool = True
    early_stopping_patience: int = 20
    early_stopping_min_delta: float = 0.0001
    early_stopping_mode: str = 'min'
    save_top_k: int = 1
    monitor_metric: str = 'val_loss'
    monitor_mode: str = 'min'
    log_every_n_steps: int = 50
    enable_progress_bar: bool = True
    enable_model_summary: bool = True

    def __post_init__(self):
        self.num_epochs = int(self.num_epochs)
        self.gradient_clip_val = None if self.gradient_clip_val is None else float(self.gradient_clip_val)
        self.accumulate_grad_batches = int(self.accumulate_grad_batches)
        self.check_val_every_n_epoch = int(self.check_val_every_n_epoch)
        self.early_stopping = bool(self.early_stopping)
        self.early_stopping_patience = int(self.early_stopping_patience)
        self.early_stopping_min_delta = float(self.early_stopping_min_delta)
        self.early_stopping_mode = str(self.early_stopping_mode)
        self.save_top_k = int(self.save_top_k)
        self.monitor_metric = str(self.monitor_metric)
        self.monitor_mode = str(self.monitor_mode)
        self.log_every_n_steps = int(self.log_every_n_steps)
        self.enable_progress_bar = bool(self.enable_progress_bar)
        self.enable_model_summary = bool(self.enable_model_summary)
        if self.num_epochs <= 0:
            raise ValueError(f'num_epochs must be positive, got {self.num_epochs}')
        if self.accumulate_grad_batches <= 0:
            raise ValueError(f'accumulate_grad_batches must be positive, got {self.accumulate_grad_batches}')
        if self.check_val_every_n_epoch <= 0:
            raise ValueError(f'check_val_every_n_epoch must be positive, got {self.check_val_every_n_epoch}')
        if self.early_stopping_mode not in ('min', 'max'):
            raise ValueError(f"early_stopping_mode must be 'min' or 'max', got {self.early_stopping_mode}")
        if self.monitor_mode not in ('min', 'max'):
            raise ValueError(f"monitor_mode must be 'min' or 'max', got {self.monitor_mode}")

@dataclass
class OptimizerConfig:
    name: str = 'Adam'
    params: dict[str, Any] = field(default_factory=lambda: {'lr': 0.0005, 'weight_decay': 0.0001, 'eps': 1e-08, 'betas': [0.9, 0.999]})

    def __post_init__(self):
        self.name = str(self.name)
        self.params = _ensure_dict(self.params)

@dataclass
class SchedulerConfig:
    name: str = 'ReduceLROnPlateau'
    params: dict[str, Any] = field(default_factory=lambda: {'mode': 'min', 'factor': 0.1, 'patience': 10, 'threshold': 0.0001, 'cooldown': 5, 'min_lr': 1e-06})

    def __post_init__(self):
        self.name = str(self.name)
        self.params = _ensure_dict(self.params)

@dataclass
class LossConfig:
    name: str = 'NMSE'
    params: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.name = str(self.name)
        self.params = _ensure_dict(self.params)

@dataclass
class ExperimentConfig:
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    loss: LossConfig = field(default_factory=LossConfig)
    seed: int = 42
    deterministic: bool = False
    accelerator: str = 'auto'
    devices: int = 1
    precision: Literal['16-mixed', 'bf16', '32', '64'] = '32'
    prefix: str = 'TDD'
    model_name: str = 'RNN'
    experiment_name: str = field(default='')
    output_dir: str = field(default='')

    def __post_init__(self):
        self.seed = int(self.seed)
        self.deterministic = bool(self.deterministic)
        self.accelerator = str(self.accelerator)
        self.devices = int(self.devices)
        self.precision = str(self.precision)
        self.prefix = str(self.prefix)
        self.model_name = str(self.model_name)
        if not self.model_name:
            self.model_name = self.model.name
        if not self.experiment_name:
            self.experiment_name = f'{self.prefix}_{self.model_name}'
        if not self.output_dir:
            self.output_dir = str(Path(DIR_OUTPUTS) / self.prefix / self.model_name)
        else:
            self.output_dir = str(self.output_dir)
        self.data.is_separate_antennas = self.model.is_separate_antennas
        if self.devices <= 0:
            raise ValueError(f'devices must be positive, got {self.devices}')
        if self.precision not in ('16-mixed', 'bf16', '32', '64'):
            raise ValueError(f"precision must be one of ['16-mixed', 'bf16', '32', '64'], got {self.precision}")

    @classmethod
    def fromDict(cls, dict_config: dict[str, Any]) -> 'ExperimentConfig':
        dict_config = dict(dict_config)
        if 'data' in dict_config and isinstance(dict_config['data'], dict):
            dict_config['data'] = DataConfig(**dict_config['data'])
        if 'model' in dict_config and isinstance(dict_config['model'], dict):
            dict_config['model'] = ModelConfig(**dict_config['model'])
        if 'training' in dict_config and isinstance(dict_config['training'], dict):
            dict_config['training'] = TrainingConfig(**dict_config['training'])
        if 'optimizer' in dict_config and isinstance(dict_config['optimizer'], dict):
            dict_config['optimizer'] = OptimizerConfig(**dict_config['optimizer'])
        if 'scheduler' in dict_config and isinstance(dict_config['scheduler'], dict):
            dict_config['scheduler'] = SchedulerConfig(**dict_config['scheduler'])
        if 'loss' in dict_config and isinstance(dict_config['loss'], dict):
            dict_config['loss'] = LossConfig(**dict_config['loss'])
        return cls(**dict_config)

    @classmethod
    def fromJson(cls, path_json: str) -> 'ExperimentConfig':
        with open(path_json, encoding='utf-8') as f:
            dict_config = json.load(f)
        return cls.fromDict(dict_config)

    @classmethod
    def fromYaml(cls, path_yaml: str) -> 'ExperimentConfig':

        def tuple_constructor(loader, node):
            return list(loader.construct_sequence(node))
        yaml.SafeLoader.add_constructor('tag:yaml.org,2002:python/tuple', tuple_constructor)
        with open(path_yaml, encoding='utf-8') as f:
            dict_config = yaml.safe_load(f)
        return cls.fromDict(dict_config)

    def toDict(self) -> dict[str, Any]:

        def _toDict(obj) -> Any:
            if hasattr(obj, '__dict__'):
                return {k: _toDict(v) for k, v in obj.__dict__.items()}
            elif isinstance(obj, (list, tuple)):
                return [_toDict(item) for item in obj]
            else:
                return obj
        return _toDict(self)

    def saveJson(self, path_json: str):
        Path(path_json).parent.mkdir(parents=True, exist_ok=True)
        with open(path_json, 'w', encoding='utf-8') as f:
            json.dump(self.toDict(), f, indent=4, ensure_ascii=False)

    def saveYaml(self, path_yaml: str):
        Path(path_yaml).parent.mkdir(parents=True, exist_ok=True)
        with open(path_yaml, 'w', encoding='utf-8') as f:
            yaml.dump(self.toDict(), f, default_flow_style=False, allow_unicode=True)

    def summary(self) -> dict[str, Any]:
        return {'scenario': 'FDD' if self.data.is_U2D else 'TDD', 'model_name_top': self.model_name, 'model_name_registry': self.model.name, 'output_dir': self.output_dir, 'batch_size': self.data.batch_size, 'train_ratio': self.data.train_ratio, 'return_metadata': self.data.return_metadata, 'add_noise_in_val': self.data.add_noise_in_val, 'checkpoint_path': self.model.checkpoint_path}
if __name__ == '__main__':
    import argparse
    from pathlib import Path
    from src.utils.data_utils import NUM_SUBCARRIERS, PRED_LEN
    parser = argparse.ArgumentParser(description='Experiment configuration management')
    parser.add_argument('--model', '-m', type=str, default='RNN', help='Model name')
    parser.add_argument('--output-dir', '-o', type=str, default='z_artifacts/config/cp', help='Output directory for config files')
    parser.add_argument('--is_U2D', '-u', action='store_true', help='Use U2D (FDD) configuration')
    parser.add_argument('--config-file', '-c', type=str, default='yaml', help='Path to config file (JSON or YAML)')
    args = parser.parse_args()
    config = ExperimentConfig()
    is_U2D = args.is_U2D
    scenario = 'FDD' if is_U2D else 'TDD'
    config.data.is_U2D = is_U2D
    model_name = args.model
    if model_name == 'RNN':
        config.model.name = f'{model_name}_{scenario}'
        config.model.is_separate_antennas = True
        config.model.checkpoint_path = None
        config.model.params = {'dim_data': NUM_SUBCARRIERS * 2, 'rnn_hidden_dim': NUM_SUBCARRIERS * 4, 'rnn_num_layers': 4, 'pred_len': PRED_LEN}
    elif model_name == 'ADAPTIVE_RNN':
        config.model.name = f'{model_name}_{scenario}'
        config.model.is_separate_antennas = True
        config.model.checkpoint_path = None
        config.model.params = {'predictor': {'dim_data': NUM_SUBCARRIERS * 2, 'rnn_hidden_dim': NUM_SUBCARRIERS * 4, 'rnn_num_layers': 4, 'pred_len': PRED_LEN}, 'controller': {'in_dim': 10, 'hidden_dim': 128, 'num_actions': 4, 'dropout': 0.1, 'use_layernorm': True}, 'low_dim': 32, 'high_dim': 128, 'full_dim': NUM_SUBCARRIERS * 2, 'low_hidden_dims': [256, 128], 'high_hidden_dims': [256, 128], 'full_hidden_dims': [512, 256], 'expert_dropout': 0.0, 'expert_use_layernorm': False, 'rate_values': [0.0, 32.0, 128.0, float(NUM_SUBCARRIERS * 2)], 'target_avg_budget': 96.0, 'peak_budget': 256.0, 'qos_threshold': 0.05, 'lambda_avg': 0.1, 'lambda_peak': 0.05, 'lambda_qos': 0.1, 'lambda_ce': 0.0, 'gumbel_tau_start': 1.0, 'gumbel_tau_end': 0.3, 'gumbel_anneal_steps': 5000, 'hard_in_eval': True}
        config.data.return_metadata = False
        config.data.add_noise_in_val = True
    else:
        raise ValueError(f'Unsupported model: {model_name}')
    config.data.is_separate_antennas = config.model.is_separate_antennas
    config.prefix = scenario
    config.model_name = model_name
    config.experiment_name = f'{config.prefix}_{config.model_name}'
    config.output_dir = str(Path(DIR_OUTPUTS) / config.prefix / config.model_name)
    config = ExperimentConfig.fromDict(config.toDict())
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if args.config_file == 'yaml':
        config.saveYaml(str(output_dir / config.model_name.lower() / f'{config.experiment_name.lower()}.yaml'))
    elif args.config_file == 'json':
        config.saveJson(str(output_dir / config.model_name.lower() / f'{config.experiment_name.lower()}.json'))
    else:
        raise ValueError(f"Unsupported config file format: {args.config_file}. Use 'yaml' or 'json'.")
