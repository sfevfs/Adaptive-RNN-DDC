from itertools import product
import logging
from pathlib import Path
import random
from typing import Any
import lightning.pytorch as pl
import torch
from torch.utils.data import DataLoader, Dataset
from src.cp.config.config import DataConfig
from src.noise.noise import gen_vanilla_noise_snr
from src.utils.data_utils import LIST_CHANNEL_MODEL, LIST_DELAY_SPREAD, LIST_MIN_SPEED_TRAIN, SNR_RANGE_GAUSSIAN_NOISE_TRAIN, _load_data, collect_fn_gather_antennas, collect_fn_separate_antennas
from src.utils.norm_utils import normalize_input
logger = logging.getLogger(__name__)
CM_TO_ID = {cm: idx for idx, cm in enumerate(LIST_CHANNEL_MODEL)}
CACHE_VERSION = 'v1_cached_clean_split'

class CachedCSIDataset(Dataset):

    def __init__(self, H_hist_clean: torch.Tensor, H_pred: torch.Tensor, return_metadata: bool=False, add_noise: bool=False, cm_id: torch.Tensor | None=None, ds_ns: torch.Tensor | None=None, ms: torch.Tensor | None=None, cm_name: list[str] | None=None):
        super().__init__()
        self.H_hist_clean = H_hist_clean
        self.H_pred = H_pred
        self.return_metadata = return_metadata
        self.add_noise = add_noise
        self.cm_id = cm_id
        self.ds_ns = ds_ns
        self.ms = ms
        self.cm_name = cm_name
        n = len(H_hist_clean)
        if len(H_pred) != n:
            raise ValueError('H_hist_clean and H_pred length mismatch')
        if self.return_metadata:
            if cm_id is None or ds_ns is None or ms is None or (cm_name is None):
                raise ValueError('Metadata requested but metadata tensors/lists are missing')
            if not len(cm_id) == len(ds_ns) == len(ms) == len(cm_name) == n:
                raise ValueError('Metadata length mismatch in CachedCSIDataset')

    def __len__(self):
        return len(self.H_hist_clean)

    def __getitem__(self, idx):
        hist = self.H_hist_clean[idx].clone()
        target = self.H_pred[idx]
        if self.add_noise:
            snr_val = random.uniform(*SNR_RANGE_GAUSSIAN_NOISE_TRAIN)
            hist = hist + gen_vanilla_noise_snr(hist, SNR=snr_val)
        if not self.return_metadata:
            return (hist, target)
        return {'hist': hist, 'target': target, 'cm_id': self.cm_id[idx], 'cm_name': self.cm_name[idx], 'ds_ns': self.ds_ns[idx], 'ms': self.ms[idx]}

class TrainValDataModule(pl.LightningDataModule):

    def __init__(self, data_config: DataConfig):
        super().__init__()
        self.data_cfg = data_config
        self.return_metadata = bool(getattr(data_config, 'return_metadata', False))
        self.add_noise_in_val = bool(getattr(data_config, 'add_noise_in_val', True))
        self.subset_stats: list[dict[str, Any]] = []
        self.train_dataset = None
        self.val_dataset = None
        self._is_setup_done = False
        self._setup_stage = None

    def _cache_root(self) -> Path:
        dataset_dir = Path(self.data_cfg.dir_dataset)
        return dataset_dir.parent / 'cache' / 'cp'

    def _cache_file(self) -> Path:
        scenario = 'FDD' if self.data_cfg.is_U2D else 'TDD'
        train_ratio_str = f'{self.data_cfg.train_ratio:.4f}'.replace('.', 'p')
        sep_str = f'sep{int(self.data_cfg.is_separate_antennas)}'
        return self._cache_root() / f'trainval_cache_{scenario}_tr{train_ratio_str}_{sep_str}_{CACHE_VERSION}.pt'

    def _load_cache_payload(self, path_cache: Path) -> dict[str, Any]:
        logger.info(f'📦 Loading cached processed dataset from: {path_cache}')
        try:
            payload = torch.load(path_cache, map_location='cpu', weights_only=False)
        except TypeError:
            payload = torch.load(path_cache, map_location='cpu')
        return payload

    def _save_cache_payload(self, path_cache: Path, payload: dict[str, Any]):
        path_cache.parent.mkdir(parents=True, exist_ok=True)
        logger.info(f'💾 Saving processed dataset cache to: {path_cache}')
        torch.save(payload, path_cache)

    def _build_cache_payload(self) -> dict[str, Any]:
        H_hist_train_list = []
        H_pred_train_list = []
        H_hist_val_list = []
        H_pred_val_list = []
        meta_train_cm_id = []
        meta_train_ds_ns = []
        meta_train_ms = []
        meta_train_cm_name = []
        meta_val_cm_id = []
        meta_val_ds_ns = []
        meta_val_ms = []
        meta_val_cm_name = []
        subset_stats: list[dict[str, Any]] = []
        total_subsets = 0
        total_train_samples = 0
        total_val_samples = 0
        logger.info(f'🔄 Building processed dataset from raw data (train_ratio={self.data_cfg.train_ratio})')
        for cm, ds, ms in product(LIST_CHANNEL_MODEL, LIST_DELAY_SPREAD, LIST_MIN_SPEED_TRAIN):
            H_hist_subset = _load_data(dir_data=Path(self.data_cfg.dir_dataset), cm=cm, ds=ds, ms=ms, is_train=True, is_gen=False, is_hist=True, is_U2D=self.data_cfg.is_U2D)
            H_pred_subset = _load_data(dir_data=Path(self.data_cfg.dir_dataset), cm=cm, ds=ds, ms=ms, is_train=True, is_gen=False, is_hist=False, is_U2D=self.data_cfg.is_U2D)
            subset_size = len(H_hist_subset)
            train_size = int(subset_size * self.data_cfg.train_ratio)
            indices = torch.randperm(subset_size, generator=torch.Generator().manual_seed(42))
            train_indices = indices[:train_size]
            val_indices = indices[train_size:]
            H_hist_train_subset = H_hist_subset[train_indices]
            H_pred_train_subset = H_pred_subset[train_indices]
            H_hist_val_subset = H_hist_subset[val_indices]
            H_pred_val_subset = H_pred_subset[val_indices]
            H_hist_train_list.append(H_hist_train_subset)
            H_pred_train_list.append(H_pred_train_subset)
            H_hist_val_list.append(H_hist_val_subset)
            H_pred_val_list.append(H_pred_val_subset)
            ds_ns_value = int(round(ds * 1000000000.0))
            cm_id_value = CM_TO_ID[cm]
            meta_train_cm_id.append(torch.full((len(H_hist_train_subset),), cm_id_value, dtype=torch.long))
            meta_train_ds_ns.append(torch.full((len(H_hist_train_subset),), ds_ns_value, dtype=torch.long))
            meta_train_ms.append(torch.full((len(H_hist_train_subset),), int(ms), dtype=torch.long))
            meta_train_cm_name.extend([cm] * len(H_hist_train_subset))
            meta_val_cm_id.append(torch.full((len(H_hist_val_subset),), cm_id_value, dtype=torch.long))
            meta_val_ds_ns.append(torch.full((len(H_hist_val_subset),), ds_ns_value, dtype=torch.long))
            meta_val_ms.append(torch.full((len(H_hist_val_subset),), int(ms), dtype=torch.long))
            meta_val_cm_name.extend([cm] * len(H_hist_val_subset))
            total_subsets += 1
            total_train_samples += len(H_hist_train_subset)
            total_val_samples += len(H_hist_val_subset)
            subset_stats.append({'cm': cm, 'cm_id': cm_id_value, 'ds_ns': ds_ns_value, 'ms': int(ms), 'subset_size': subset_size, 'train_size': len(H_hist_train_subset), 'val_size': len(H_hist_val_subset)})
            logger.info(f'📊 Subset CM={cm}, DS={ds_ns_value}ns, MS={ms}: {subset_size} total → {len(H_hist_train_subset)} train, {len(H_hist_val_subset)} val')
            del (H_hist_subset, H_pred_subset, H_hist_train_subset, H_pred_train_subset, H_hist_val_subset, H_pred_val_subset)
        H_hist_train = torch.cat(H_hist_train_list, dim=0)
        H_pred_train = torch.cat(H_pred_train_list, dim=0)
        H_hist_val = torch.cat(H_hist_val_list, dim=0)
        H_pred_val = torch.cat(H_pred_val_list, dim=0)
        train_cm_id = torch.cat(meta_train_cm_id, dim=0)
        train_ds_ns = torch.cat(meta_train_ds_ns, dim=0)
        train_ms = torch.cat(meta_train_ms, dim=0)
        val_cm_id = torch.cat(meta_val_cm_id, dim=0)
        val_ds_ns = torch.cat(meta_val_ds_ns, dim=0)
        val_ms = torch.cat(meta_val_ms, dim=0)
        del H_hist_train_list, H_pred_train_list, H_hist_val_list, H_pred_val_list
        del meta_train_cm_id, meta_train_ds_ns, meta_train_ms
        del meta_val_cm_id, meta_val_ds_ns, meta_val_ms
        logger.info('✅ Split completed:')
        logger.info(f'   {total_subsets} subsets processed')
        logger.info(f'   ▶ Training: {total_train_samples} samples from ALL subsets')
        logger.info(f'   ▶ Validation: {total_val_samples} samples from ALL subsets')
        logger.info(f'   ▶ Raw data shapes: hist={H_hist_train[0].shape}, pred={H_pred_train[0].shape}')
        H_hist_train, H_pred_train = normalize_input(H_hist_train, H_pred_train, is_U2D=self.data_cfg.is_U2D)
        H_hist_val, H_pred_val = normalize_input(H_hist_val, H_pred_val, is_U2D=self.data_cfg.is_U2D)
        assert H_pred_train is not None, 'H_pred_train should not be None'
        assert H_pred_val is not None, 'H_pred_val should not be None'
        payload = {'cache_version': CACHE_VERSION, 'scenario': 'FDD' if self.data_cfg.is_U2D else 'TDD', 'train_ratio': float(self.data_cfg.train_ratio), 'is_separate_antennas': bool(self.data_cfg.is_separate_antennas), 'H_hist_train_clean': H_hist_train.cpu(), 'H_pred_train': H_pred_train.cpu(), 'H_hist_val_clean': H_hist_val.cpu(), 'H_pred_val': H_pred_val.cpu(), 'train_cm_id': train_cm_id.cpu(), 'train_ds_ns': train_ds_ns.cpu(), 'train_ms': train_ms.cpu(), 'train_cm_name': meta_train_cm_name, 'val_cm_id': val_cm_id.cpu(), 'val_ds_ns': val_ds_ns.cpu(), 'val_ms': val_ms.cpu(), 'val_cm_name': meta_val_cm_name, 'subset_stats': subset_stats}
        return payload

    def setup(self, stage=None):
        if self._is_setup_done:
            logger.info(f'⏭️ setup already completed previously (stage={self._setup_stage}), skipping rebuild for stage={stage}')
            return
        path_cache = self._cache_file()
        if path_cache.exists():
            payload = self._load_cache_payload(path_cache)
        else:
            payload = self._build_cache_payload()
            self._save_cache_payload(path_cache, payload)
        self._init_from_cache_payload(payload)
        self._is_setup_done = True
        self._setup_stage = stage

    def _init_from_cache_payload(self, payload: dict[str, Any]):
        self.subset_stats = payload['subset_stats']
        H_hist_train_clean = payload['H_hist_train_clean']
        H_pred_train = payload['H_pred_train']
        H_hist_val_clean = payload['H_hist_val_clean']
        H_pred_val = payload['H_pred_val']
        if self.return_metadata:
            self.train_dataset = CachedCSIDataset(H_hist_clean=H_hist_train_clean, H_pred=H_pred_train, return_metadata=True, add_noise=True, cm_id=payload['train_cm_id'], ds_ns=payload['train_ds_ns'], ms=payload['train_ms'], cm_name=payload['train_cm_name'])
            self.val_dataset = CachedCSIDataset(H_hist_clean=H_hist_val_clean, H_pred=H_pred_val, return_metadata=True, add_noise=self.add_noise_in_val, cm_id=payload['val_cm_id'], ds_ns=payload['val_ds_ns'], ms=payload['val_ms'], cm_name=payload['val_cm_name'])
            logger.info('📦 Metadata-aware cached datasets enabled')
        else:
            self.train_dataset = CachedCSIDataset(H_hist_clean=H_hist_train_clean, H_pred=H_pred_train, return_metadata=False, add_noise=True)
            self.val_dataset = CachedCSIDataset(H_hist_clean=H_hist_val_clean, H_pred=H_pred_val, return_metadata=False, add_noise=self.add_noise_in_val)
            logger.info('📦 Standard cached tuple datasets enabled')
        logger.info(f'✅ Final datasets: Train={len(self.train_dataset)}, Val={len(self.val_dataset)}')

    def _collate_with_metadata(self, batch, base_collate_fn):
        payload_batch = [(sample['hist'], sample['target']) for sample in batch]
        hist_batch, target_batch = base_collate_fn(payload_batch)
        if self.data_cfg.is_separate_antennas:
            cm_id_list = []
            cm_name_list = []
            ds_ns_list = []
            ms_list = []
            for sample in batch:
                hist_sample = sample['hist']
                repeat_n = int(hist_sample.shape[0]) if hist_sample.dim() >= 3 else 1
                cm_id_list.extend([int(sample['cm_id'])] * repeat_n)
                cm_name_list.extend([sample['cm_name']] * repeat_n)
                ds_ns_list.extend([int(sample['ds_ns'])] * repeat_n)
                ms_list.extend([int(sample['ms'])] * repeat_n)
            meta = {'hist': hist_batch, 'target': target_batch, 'cm_id': torch.tensor(cm_id_list, dtype=torch.long), 'cm_name': cm_name_list, 'ds_ns': torch.tensor(ds_ns_list, dtype=torch.long), 'ms': torch.tensor(ms_list, dtype=torch.long)}
        else:
            meta = {'hist': hist_batch, 'target': target_batch, 'cm_id': torch.tensor([int(sample['cm_id']) for sample in batch], dtype=torch.long), 'cm_name': [sample['cm_name'] for sample in batch], 'ds_ns': torch.tensor([int(sample['ds_ns']) for sample in batch], dtype=torch.long), 'ms': torch.tensor([int(sample['ms']) for sample in batch], dtype=torch.long)}
        return meta

    def _get_collate_fn(self):
        if self.data_cfg.is_separate_antennas:
            base_collate = collect_fn_separate_antennas
        else:
            base_collate = collect_fn_gather_antennas
        if not self.return_metadata:
            return base_collate
        return lambda batch: self._collate_with_metadata(batch, base_collate)

    def train_dataloader(self):
        collate_fn = self._get_collate_fn()
        return DataLoader(self.train_dataset, batch_size=self.data_cfg.batch_size, shuffle=self.data_cfg.shuffle, num_workers=0, collate_fn=collate_fn)

    def val_dataloader(self):
        collate_fn = self._get_collate_fn()
        return DataLoader(self.val_dataset, batch_size=self.data_cfg.batch_size, shuffle=False, num_workers=0, collate_fn=collate_fn)

    def get_data_shapes(self):
        if not hasattr(self, 'train_dataset') or self.train_dataset is None or len(self.train_dataset) == 0:
            return (None, None)
        loader = self.train_dataloader()
        batch = next(iter(loader))
        if isinstance(batch, dict):
            hist_batch = batch['hist']
            pred_batch = batch['target']
        else:
            hist_batch, pred_batch = batch
        return (hist_batch.shape, pred_batch.shape)

    def get_subset_statistics(self):
        return self.subset_stats
