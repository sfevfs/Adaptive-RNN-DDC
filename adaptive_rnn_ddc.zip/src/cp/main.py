import lightning.pytorch as pl
import torch
from src.cp.dataset.data_module import TrainValDataModule
from src.utils.main_utils import arg_parser, make_checkpoint_callback, make_config, make_early_stopping_callback, make_logger, make_output_dir, make_tensorboard_logger
from src.utils.model_utils import load_model
torch.set_float32_matmul_precision('medium')

def _log_basic_config(logger, args, config, output_dir):
    logger.info(f'load config from - {args.hparams_csi_pred}')
    logger.info(f'output directory - {output_dir}')
    logger.info(f'seed - {config.seed}')
    if hasattr(config, 'summary'):
        logger.info(f'config summary - {config.summary()}')

def _log_device_info(logger):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if torch.cuda.is_available():
        device_name = torch.cuda.get_device_name(0)
    else:
        device_name = 'CPU'
    logger.info(f'device - {device} | {device_name}')
    return device

def _log_adaptive_config(logger, config):
    if not str(config.model.name).startswith('ADAPTIVE_RNN'):
        return
    params = config.model.params
    logger.info('adaptive config detected - dumping key hyperparameters')
    rate_values = params.get('rate_values', None)
    low_dim = params.get('low_dim', None)
    high_dim = params.get('high_dim', None)
    full_dim = params.get('full_dim', None)
    logger.info(f"adaptive predictor - {params.get('predictor', {})}")
    logger.info(f"adaptive controller - {params.get('controller', {})}")
    logger.info(f'adaptive experts - low_dim={low_dim}, high_dim={high_dim}, full_dim={full_dim}')
    logger.info(f"adaptive budget - rate_values={rate_values}, target_avg_budget={params.get('target_avg_budget', None)}, peak_budget={params.get('peak_budget', None)}, qos_threshold={params.get('qos_threshold', None)}")
    logger.info(f"adaptive loss weights - lambda_avg={params.get('lambda_avg', None)}, lambda_peak={params.get('lambda_peak', None)}, lambda_qos={params.get('lambda_qos', None)}, lambda_ce={params.get('lambda_ce', None)}")
    logger.info(f"adaptive routing - gumbel_tau_start={params.get('gumbel_tau_start', None)}, gumbel_tau_end={params.get('gumbel_tau_end', None)}, gumbel_anneal_steps={params.get('gumbel_anneal_steps', None)}, hard_in_eval={params.get('hard_in_eval', None)}")

def _probe_data_module(logger, datamodule):
    try:
        datamodule.setup('fit')
        hist_shape, pred_shape = datamodule.get_data_shapes()
        logger.info(f'data module ready - hist shape={hist_shape}, target shape={pred_shape}')
    except Exception as e:
        logger.warning(f'data module probing failed before fit: {e}')

def build_trainer(config, output_dir):
    training_cfg = config.training
    ckpt_cb = make_checkpoint_callback(config=config, output_dir=output_dir)
    earlystop_cb = make_early_stopping_callback(config=config)
    tb_logger = make_tensorboard_logger(config=config, output_dir=output_dir)
    trainer = pl.Trainer(max_epochs=training_cfg.num_epochs, accelerator=config.accelerator, devices=config.devices, precision=config.precision, callbacks=[ckpt_cb, earlystop_cb], logger=tb_logger, log_every_n_steps=training_cfg.log_every_n_steps, gradient_clip_val=training_cfg.gradient_clip_val, accumulate_grad_batches=training_cfg.accumulate_grad_batches, check_val_every_n_epoch=training_cfg.check_val_every_n_epoch, enable_progress_bar=training_cfg.enable_progress_bar, enable_model_summary=training_cfg.enable_model_summary)
    return (trainer, ckpt_cb, tb_logger)

def main():
    parser = arg_parser()
    args = parser.parse_args()
    config = make_config(args.hparams_csi_pred)
    pl.seed_everything(config.seed, workers=True)
    output_dir = make_output_dir(config)
    logger = make_logger(output_dir)
    _log_basic_config(logger, args, config, output_dir)
    _log_adaptive_config(logger, config)
    device = _log_device_info(logger)
    model = load_model(config, device=device)
    logger.info(f'model - {model!s}')
    datamodule = TrainValDataModule(config.data)
    logger.info('setup data module')
    _probe_data_module(logger, datamodule)
    trainer, ckpt_cb, tb_logger = build_trainer(config, output_dir)
    logger.info('trainer initialized')
    if config.model.checkpoint_path is not None:
        logger.info(f'checkpoint restore was handled by load_model() from: {config.model.checkpoint_path}')
        logger.info('starting fit with restored model weights...')
    else:
        logger.info('starting training from scratch...')
    trainer.fit(model, datamodule)
    logger.info(f'training complete. best checkpoint: {ckpt_cb.best_model_path}')
    logger.info(f'tensorboard logs saved at: {tb_logger.log_dir}')
    logger.info(f'output directory: {output_dir}')
    logger.info(f"run 'tensorboard --logdir {tb_logger.log_dir}' to view TensorBoard logs.")
if __name__ == '__main__':
    main()
