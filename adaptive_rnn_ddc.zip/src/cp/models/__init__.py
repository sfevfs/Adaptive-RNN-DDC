from src.cp.models.baseline_models.np import NOPREDICTMODEL
from src.cp.models.baseline_models.rnn import RNN_pl
from src.cp.models.baseline_models.alc_rnn import ALCRNN_pl
from src.cp.models.adaptive_feedback.adaptive_rnn import AdaptiveRNN_pl

class PREDICTORS:
    NP_FDD = NOPREDICTMODEL
    NP_TDD = NOPREDICTMODEL
    RNN_FDD = RNN_pl
    RNN_TDD = RNN_pl
    ALC_RNN_FDD = ALCRNN_pl
    ALC_RNN_TDD = ALCRNN_pl
    ADAPTIVE_RNN_FDD = AdaptiveRNN_pl
    ADAPTIVE_RNN_TDD = AdaptiveRNN_pl
