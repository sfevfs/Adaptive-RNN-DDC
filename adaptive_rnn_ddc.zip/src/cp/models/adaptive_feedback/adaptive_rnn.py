import os
import torch
import torch.nn.functional as F
from src.cp.config.config import ExperimentConfig
from src.cp.models.baseline_models.alc_rnn import ALCRNN
from src.cp.models.common.base import BaseCSIModel
from src.cp.models.adaptive_feedback.controller import BudgetController, TwoStageBudgetController, compute_temporal_features, sample_actions_gumbel, deterministic_actions, expected_budget
from src.cp.models.adaptive_feedback.experts import ExpertBank
ACTION_NAMES = ('skip', 'low', 'high', 'refresh')

class AdaptiveRNN_pl(BaseCSIModel):

    def __init__(self, config: ExperimentConfig, *args, **kwargs):
        super().__init__(optimizer_config=config.optimizer, scheduler_config=config.scheduler, loss_config=config.loss)
        self.name = 'ADAPTIVE_RNN'
        self.is_separate_antennas = config.model.is_separate_antennas
        self.save_hyperparameters({'model': config.model})
        params = config.model.params
        if 'predictor' in params:
            predictor_params = params['predictor']
        else:
            predictor_params = {'dim_data': params['dim_data'], 'rnn_hidden_dim': params['rnn_hidden_dim'], 'rnn_num_layers': params.get('rnn_num_layers', 2), 'pred_len': params.get('pred_len', 4)}
        self.predictor = ALCRNN(**predictor_params)
        self.dim_data = int(predictor_params['dim_data'])
        self.pred_len = int(predictor_params.get('pred_len', 4))
        controller_params = params.get('controller', {})
        self.controller_type = str(params.get('controller_type', controller_params.get('type', 'mlp'))).lower()
        if self.controller_type in ('two_stage', 'twostage', 'two-stage', 'hierarchical'):
            controller_cls = TwoStageBudgetController
        else:
            controller_cls = BudgetController
        self.controller = controller_cls(in_dim=int(controller_params.get('in_dim', 10)), hidden_dim=int(controller_params.get('hidden_dim', 128)), num_actions=int(controller_params.get('num_actions', 4)), dropout=float(controller_params.get('dropout', 0.1)), use_layernorm=bool(controller_params.get('use_layernorm', True)), use_context=bool(controller_params.get('use_context', False)), cm_vocab_size=int(controller_params.get('cm_vocab_size', 16)), cm_emb_dim=int(controller_params.get('cm_emb_dim', 8)), context_hidden_dim=int(controller_params.get('context_hidden_dim', 32)), budget_normalizer=float(controller_params.get('budget_normalizer', 256.0)), context_scale_init=float(controller_params.get('context_scale_init', 0.1)), use_cm_embedding=bool(controller_params.get('use_cm_embedding', True)), use_film_context=bool(controller_params.get('use_film_context', False)), context_mid_ds_threshold=float(controller_params.get('context_mid_ds_threshold', 0.5)), context_high_ds_threshold=float(controller_params.get('context_high_ds_threshold', 0.875)))
        if self.controller.num_actions != 4:
            raise ValueError(f'Current implementation assumes 4 actions, got {self.controller.num_actions}')
        self.use_two_stage_loss = bool(params.get('use_two_stage_loss', self.controller_type in ('two_stage', 'twostage', 'two-stage', 'hierarchical')))
        self.two_stage_hr_weight = float(params.get('two_stage_hr_weight', 1.0))
        self.two_stage_gate_threshold = float(params.get('two_stage_gate_threshold', 0.5))
        env_two_stage_gate_threshold = os.environ.get('ADAPTIVE_TWO_STAGE_GATE_THRESHOLD', None)
        if env_two_stage_gate_threshold is not None:
            self.two_stage_gate_threshold = float(env_two_stage_gate_threshold)
        self.two_stage_gate_threshold_high = float(params.get('two_stage_gate_threshold_high', self.two_stage_gate_threshold))
        self.two_stage_gate_threshold_refresh = float(params.get('two_stage_gate_threshold_refresh', self.two_stage_gate_threshold))
        env_two_stage_gate_threshold_high = os.environ.get('ADAPTIVE_TWO_STAGE_GATE_THRESHOLD_HIGH', None)
        if env_two_stage_gate_threshold_high is not None:
            self.two_stage_gate_threshold_high = float(env_two_stage_gate_threshold_high)
        env_two_stage_gate_threshold_refresh = os.environ.get('ADAPTIVE_TWO_STAGE_GATE_THRESHOLD_REFRESH', None)
        if env_two_stage_gate_threshold_refresh is not None:
            self.two_stage_gate_threshold_refresh = float(env_two_stage_gate_threshold_refresh)
        self.use_non_high_ds_eval_calibration = bool(params.get('use_non_high_ds_eval_calibration', True))
        self.non_high_ds_threshold_ns = float(params.get('non_high_ds_threshold_ns', params.get('high_ds_threshold_ns', 350.0)))
        self.non_high_ds_gate_threshold = float(params.get('non_high_ds_gate_threshold', 0.75))
        self.non_high_ds_refresh_threshold = float(params.get('non_high_ds_refresh_threshold', 0.9))
        env_nonhigh_gate = os.environ.get('ADAPTIVE_NON_HIGH_DS_GATE_THRESHOLD', None)
        if env_nonhigh_gate is not None:
            self.non_high_ds_gate_threshold = float(env_nonhigh_gate)
        env_nonhigh_refresh = os.environ.get('ADAPTIVE_NON_HIGH_DS_REFRESH_THRESHOLD', None)
        if env_nonhigh_refresh is not None:
            self.non_high_ds_refresh_threshold = float(env_nonhigh_refresh)
        env_nonhigh_enable = os.environ.get('ADAPTIVE_USE_NON_HIGH_DS_EVAL_CALIBRATION', None)
        if env_nonhigh_enable is not None:
            self.use_non_high_ds_eval_calibration = env_nonhigh_enable.strip().lower() in ('1', 'true', 'yes', 'y', 'on')
        self.high_ds_gate_boost = float(params.get('high_ds_gate_boost', 0.0))
        self.high_ds_low_penalty = float(params.get('high_ds_low_penalty', 0.0))
        self.high_ds_threshold_ns = float(params.get('high_ds_threshold_ns', 350.0))
        self.high_ds_hr_spectral_prior_strength = float(params.get('high_ds_hr_spectral_prior_strength', 0.0))
        self.high_ds_hr_spectral_threshold = float(params.get('high_ds_hr_spectral_threshold', 1.05))
        self.high_ds_hr_spectral_feature_index = int(params.get('high_ds_hr_spectral_feature_index', 13))
        self.expert_bank = ExpertBank(in_dim=self.dim_data, low_bottleneck_dim=int(params.get('low_dim', 32)), high_bottleneck_dim=int(params.get('high_dim', 128)), full_bottleneck_dim=int(params.get('full_dim', 256)), low_hidden_dims=tuple(params.get('low_hidden_dims', [256, 128])), high_hidden_dims=tuple(params.get('high_hidden_dims', [256, 128])), full_hidden_dims=tuple(params.get('full_hidden_dims', [512, 256])), dropout=float(params.get('expert_dropout', 0.0)), use_layernorm=bool(params.get('expert_use_layernorm', False)), expert_type=str(params.get('expert_type', 'vector')), pred_len=self.pred_len, spectral_channels=int(params.get('expert_spectral_channels', 16)), temporal_hidden_dim=int(params.get('expert_temporal_hidden_dim', 128)), use_temporal=bool(params.get('expert_use_temporal', True)))
        rate_values = params.get('rate_values', [0.0, 32.0, 128.0, float(self.dim_data)])
        if len(rate_values) != 4:
            raise ValueError(f'rate_values must have length 4, got {rate_values}')
        self.register_buffer('rate_values', torch.tensor(rate_values, dtype=torch.float32))
        self.target_avg_budget = float(params.get('target_avg_budget', 96.0))
        self.peak_budget = float(params.get('peak_budget', 256.0))
        self.qos_threshold = float(params.get('qos_threshold', 0.05))
        self.lambda_rec = float(params.get('lambda_rec', 1.0))
        self.lambda_avg = float(params.get('lambda_avg', 0.1))
        self.lambda_peak = float(params.get('lambda_peak', 0.05))
        self.lambda_qos = float(params.get('lambda_qos', 0.1))
        self.lambda_ce = float(params.get('lambda_ce', 0.0))
        self.lambda_base = float(params.get('lambda_base', 0.0))
        self.gumbel_tau_start = float(params.get('gumbel_tau_start', 1.0))
        self.gumbel_tau_end = float(params.get('gumbel_tau_end', 0.3))
        self.gumbel_anneal_steps = int(params.get('gumbel_anneal_steps', 5000))
        self.hard_in_eval = bool(params.get('hard_in_eval', True))
        self.train_route_mode = str(params.get('train_route_mode', 'st_argmax')).lower()
        self.train_hard_gumbel = bool(params.get('train_hard_gumbel', True))
        self.freeze_predictor = bool(params.get('freeze_predictor', False))
        self.freeze_controller = bool(params.get('freeze_controller', False))
        self.freeze_experts = bool(params.get('freeze_experts', False))
        self.use_oracle_ce = bool(params.get('use_oracle_ce', False))
        self.disable_skip_action = bool(params.get('disable_skip_action', False))
        self.use_cost_teacher = bool(params.get('use_cost_teacher', False))
        self.cost_teacher_budget_lambda = float(params.get('cost_teacher_budget_lambda', 0.0001))
        self.cost_teacher_skip_penalty = float(params.get('cost_teacher_skip_penalty', 0.001))
        self.cost_teacher_low_penalty = float(params.get('cost_teacher_low_penalty', 0.0))
        self.cost_teacher_high_penalty = float(params.get('cost_teacher_high_penalty', 0.0))
        self.cost_teacher_refresh_penalty = float(params.get('cost_teacher_refresh_penalty', 0.0))
        self.cost_teacher_ce_weight = float(params.get('cost_teacher_ce_weight', self.lambda_ce))
        cost_teacher_class_weights = params.get('cost_teacher_class_weights', None)
        if cost_teacher_class_weights is None:
            cost_teacher_class_weights = [1.0, 1.0, 1.0, 1.0]
        if len(cost_teacher_class_weights) != 4:
            raise ValueError('cost_teacher_class_weights must have length 4')
        self.register_buffer('cost_teacher_class_weights', torch.tensor(cost_teacher_class_weights, dtype=torch.float32))
        self.use_soft_cost_teacher = bool(params.get('use_soft_cost_teacher', False))
        self.soft_cost_teacher_temperature = float(params.get('soft_cost_teacher_temperature', 5e-05))
        self.soft_cost_teacher_kl_weight = float(params.get('soft_cost_teacher_kl_weight', self.cost_teacher_ce_weight))
        oracle_quantiles = params.get('oracle_quantiles', [0.5, 0.8, 0.95])
        if len(oracle_quantiles) != 3:
            raise ValueError('oracle_quantiles must have length 3')
        self.oracle_quantiles = [float(x) for x in oracle_quantiles]
        self.predictor_pretrained_path = params.get('predictor_pretrained_path', None)
        self.adaptive_pretrained_path = params.get('adaptive_pretrained_path', None)
        self.expert_pretrain_mode = bool(params.get('expert_pretrain_mode', False))
        self.lambda_low = float(params.get('lambda_low', 1.0))
        self.lambda_high = float(params.get('lambda_high', 1.0))
        self.lambda_refresh = float(params.get('lambda_refresh', 1.0))
        self._maybe_load_full_adaptive()
        self._maybe_load_pretrained_predictor()
        self._set_module_trainability()

    def __str__(self):
        return self.name

    def _safe_torch_load(self, ckpt_path: str):
        try:
            checkpoint = torch.load(ckpt_path, map_location='cpu', weights_only=False)
        except TypeError:
            checkpoint = torch.load(ckpt_path, map_location='cpu')
        except Exception as e:
            raise RuntimeError(f'Failed to load checkpoint from {ckpt_path}. Original error: {e}') from e
        return checkpoint

    def _extract_state_dict(self, checkpoint):
        if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
            return checkpoint['state_dict']
        if isinstance(checkpoint, dict):
            return checkpoint
        raise TypeError('Unsupported checkpoint format')

    def _maybe_load_full_adaptive(self):
        ckpt_path = self.adaptive_pretrained_path
        if ckpt_path in (None, '', 'null', 'None'):
            return
        ckpt_path = str(ckpt_path)
        if not os.path.isfile(ckpt_path):
            raise FileNotFoundError(f'adaptive_pretrained_path not found: {ckpt_path}')
        checkpoint = self._safe_torch_load(ckpt_path)
        state_dict = self._extract_state_dict(checkpoint)
        current_state = self.state_dict()
        filtered_state = {}
        skipped_mismatch = []
        skipped_unexpected = []
        for key, value in state_dict.items():
            if key not in current_state:
                skipped_unexpected.append(key)
                continue
            if not hasattr(value, 'shape'):
                skipped_unexpected.append(key)
                continue
            old_shape = tuple(value.shape)
            new_shape = tuple(current_state[key].shape)
            if old_shape == new_shape:
                filtered_state[key] = value
            else:
                skipped_mismatch.append((key, old_shape, new_shape))
        missing, unexpected = self.load_state_dict(filtered_state, strict=False)
        print(f'[AdaptiveRNN] Loaded compatible full adaptive weights from: {ckpt_path}')
        print(f'[AdaptiveRNN] Full model missing keys: {missing}')
        print(f'[AdaptiveRNN] Full model unexpected keys: {unexpected}')
        if skipped_mismatch:
            print('[AdaptiveRNN] Skipped mismatched full-model keys:')
            for key, old_shape, new_shape in skipped_mismatch:
                print(f'  - {key}: checkpoint {old_shape} -> current {new_shape}')
        if skipped_unexpected:
            print('[AdaptiveRNN] Skipped unexpected full-model keys:')
            for key in skipped_unexpected[:30]:
                print(f'  - {key}')
            if len(skipped_unexpected) > 30:
                print(f'  ... and {len(skipped_unexpected) - 30} more')

    def _maybe_load_pretrained_predictor(self):
        ckpt_path = self.predictor_pretrained_path
        if ckpt_path in (None, '', 'null', 'None'):
            return
        ckpt_path = str(ckpt_path)
        if not os.path.isfile(ckpt_path):
            raise FileNotFoundError(f'predictor_pretrained_path not found: {ckpt_path}')
        checkpoint = self._safe_torch_load(ckpt_path)
        state_dict = self._extract_state_dict(checkpoint)
        predictor_state_dict = {}
        for key, value in state_dict.items():
            if key.startswith('model.'):
                predictor_state_dict[key[len('model.'):]] = value
            elif key.startswith('predictor.'):
                predictor_state_dict[key[len('predictor.'):]] = value
            else:
                predictor_state_dict[key] = value
        missing, unexpected = self.predictor.load_state_dict(predictor_state_dict, strict=False)
        print(f'[AdaptiveRNN] Loaded predictor pretrained weights from: {ckpt_path}')
        print(f'[AdaptiveRNN] Predictor missing keys: {missing}')
        print(f'[AdaptiveRNN] Predictor unexpected keys: {unexpected}')

    @staticmethod
    def _set_requires_grad(module, requires_grad: bool):
        for p in module.parameters():
            p.requires_grad = requires_grad

    def _set_module_trainability(self):
        self._set_requires_grad(self.predictor, not self.freeze_predictor)
        self._set_requires_grad(self.controller, not self.freeze_controller)
        self._set_requires_grad(self.expert_bank, not self.freeze_experts)
        if self.freeze_predictor:
            self.predictor.eval()
        if self.freeze_controller:
            self.controller.eval()
        if self.freeze_experts:
            self.expert_bank.eval()

    def train(self, mode: bool=True):
        super().train(mode)
        if self.freeze_predictor:
            self.predictor.eval()
        if self.freeze_controller:
            self.controller.eval()
        if self.freeze_experts:
            self.expert_bank.eval()
        return self

    def _get_current_tau(self) -> float:
        if self.gumbel_anneal_steps <= 0:
            return self.gumbel_tau_end
        try:
            step = self.global_step
        except RuntimeError:
            return self.gumbel_tau_end
        if step >= self.gumbel_anneal_steps:
            return self.gumbel_tau_end
        ratio = step / float(self.gumbel_anneal_steps)
        tau = self.gumbel_tau_start + ratio * (self.gumbel_tau_end - self.gumbel_tau_start)
        return float(tau)

    def _extract_batch(self, batch):
        if isinstance(batch, (tuple, list)):
            hist, target = batch[:2]
            meta = {}
        elif isinstance(batch, dict):
            hist = batch['hist']
            target = batch['target']
            meta = {k: v for k, v in batch.items() if k not in ('hist', 'target')}
        else:
            raise TypeError(f'Unsupported batch type: {type(batch)}')
        return (hist, target, meta)

    def _predict_base(self, hist: torch.Tensor, meta: dict | None=None) -> torch.Tensor:
        if self.freeze_predictor:
            with torch.no_grad():
                pred_base = self.predictor(hist, meta=meta)
            pred_base = pred_base.detach()
        else:
            pred_base = self.predictor(hist, meta=meta)
        return pred_base

    def _build_soft_cost_teacher_probs(self, candidates: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if candidates.dim() != 4:
            raise ValueError(f'Expected candidates [B,L,A,D], got {candidates.shape}')
        if target.dim() != 3:
            raise ValueError(f'Expected target [B,L,D], got {target.shape}')
        diff = candidates - target.unsqueeze(2)
        err_power = diff.pow(2).sum(dim=-1)
        true_power = target.pow(2).sum(dim=-1, keepdim=True).clamp_min(1e-12)
        nmse_by_action = err_power / true_power
        budget_cost = self.cost_teacher_budget_lambda * self.rate_values.view(1, 1, -1)
        penalty = torch.tensor([self.cost_teacher_skip_penalty, self.cost_teacher_low_penalty, self.cost_teacher_high_penalty, self.cost_teacher_refresh_penalty], device=candidates.device, dtype=candidates.dtype).view(1, 1, -1)
        total_cost = nmse_by_action + budget_cost + penalty
        if self.disable_skip_action:
            total_cost = total_cost.clone()
            total_cost[..., 0] = 1000000000.0
        tau = max(self.soft_cost_teacher_temperature, 1e-12)
        teacher_probs = torch.softmax(-total_cost / tau, dim=-1)
        if self.disable_skip_action:
            teacher_probs = teacher_probs.clone()
            teacher_probs[..., 0] = 0.0
            teacher_probs = teacher_probs / teacher_probs.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        return teacher_probs

    def _build_candidates(self, pred_base: torch.Tensor, target: torch.Tensor):
        expert_out = self.expert_bank(pred_base=pred_base, target=target)
        candidates = torch.stack([expert_out['skip_hat'], expert_out['low_hat'], expert_out['high_hat'], expert_out['refresh_hat']], dim=2)
        return (candidates, expert_out)

    def _straight_through_argmax(self, logits: torch.Tensor, tau: float) -> torch.Tensor:
        tau = max(float(tau), 1e-06)
        probs_soft = F.softmax(logits / tau, dim=-1)
        action_idx = torch.argmax(probs_soft, dim=-1)
        probs_hard = F.one_hot(action_idx, num_classes=probs_soft.size(-1)).to(probs_soft.dtype)
        probs_st = probs_hard - probs_soft.detach() + probs_soft
        return probs_st

    def _match_controller_feature_dim(self, ctrl_feat: torch.Tensor) -> torch.Tensor:
        expected = int(getattr(self.controller, 'in_dim', ctrl_feat.size(-1)))
        current = int(ctrl_feat.size(-1))
        if current == expected:
            return ctrl_feat
        if current > expected:
            return ctrl_feat[..., :expected]
        pad = torch.zeros(*ctrl_feat.shape[:-1], expected - current, device=ctrl_feat.device, dtype=ctrl_feat.dtype)
        return torch.cat([ctrl_feat, pad], dim=-1)

    def _get_high_ds_flag(self, meta: dict | None, bsz: int, pred_len: int, device, dtype) -> torch.Tensor | None:
        if meta is None:
            return None
        ds_value = meta.get('ds_ns', None)
        if ds_value is None:
            ds_value = meta.get('ds', None)
        if ds_value is None:
            return None
        if hasattr(self.controller, '_to_1d_tensor'):
            ds_1d = self.controller._to_1d_tensor(ds_value, bsz, device, torch.float32, default_value=0.0)
        else:
            ds_1d = torch.as_tensor(ds_value, device=device, dtype=torch.float32).reshape(-1)
            if ds_1d.numel() == 1:
                ds_1d = ds_1d.expand(bsz)
            elif ds_1d.numel() != bsz:
                ds_1d = ds_1d[:bsz]
        max_abs = ds_1d.abs().max().item() if ds_1d.numel() > 0 else 0.0
        if max_abs < 0.001:
            ds_ns = ds_1d * 1000000000.0
        else:
            ds_ns = ds_1d
        high_ds = (ds_ns >= self.high_ds_threshold_ns).to(dtype=dtype)
        return high_ds.view(bsz, 1).expand(bsz, pred_len)

    def _build_high_ds_mask(self, meta=None, bsz: int | None=None, pred_len: int | None=None, device=None, dtype=None):
        if meta is None:
            return None
        ds = None
        if isinstance(meta, dict):
            for key in ('ds_ns', 'delay_spread_ns', 'delay_ns', 'ds', 'delay_spread', 'delay'):
                if key in meta:
                    ds = meta[key]
                    break
        else:
            for key in ('ds_ns', 'delay_spread_ns', 'delay_ns', 'ds', 'delay_spread', 'delay'):
                if hasattr(meta, key):
                    ds = getattr(meta, key)
                    break
        if ds is None:
            return None
        if not torch.is_tensor(ds):
            ds = torch.as_tensor(ds, device=device, dtype=dtype)
        else:
            ds = ds.to(device=device, dtype=dtype)
        ds = ds.squeeze()
        if ds.dim() == 0:
            if bsz is None:
                bsz = 1
            ds = ds.view(1).expand(bsz)
        elif ds.dim() > 1:
            ds = ds.reshape(ds.shape[0], -1)[:, 0]
        if bsz is not None and ds.numel() == 1:
            ds = ds.view(1).expand(bsz)
        max_abs = torch.nan_to_num(ds.detach().abs(), nan=0.0).max()
        if max_abs < 0.001:
            ds_ns = ds * 1000000000.0
        else:
            ds_ns = ds
        high_ds = (ds_ns >= float(getattr(self, 'high_ds_threshold_ns', 350.0))).to(dtype=dtype)
        if pred_len is not None:
            if high_ds.dim() == 1:
                high_ds = high_ds.view(-1, 1).expand(-1, pred_len)
            elif high_ds.dim() == 2 and high_ds.size(1) == 1:
                high_ds = high_ds.expand(-1, pred_len)
        return high_ds

    def _apply_high_ds_gate_prior(self, gate_logits: torch.Tensor | None, meta: dict | None) -> torch.Tensor | None:
        if gate_logits is None:
            return None
        if self.high_ds_gate_boost == 0.0 and self.high_ds_low_penalty == 0.0:
            return gate_logits
        bsz, pred_len = gate_logits.shape[:2]
        high_ds = self._get_high_ds_flag(meta=meta, bsz=bsz, pred_len=pred_len, device=gate_logits.device, dtype=gate_logits.dtype)
        if high_ds is None:
            return gate_logits
        adjusted = gate_logits.clone()
        if self.high_ds_low_penalty != 0.0:
            adjusted[..., 0] = adjusted[..., 0] - self.high_ds_low_penalty * high_ds
        if self.high_ds_gate_boost != 0.0:
            adjusted[..., 1] = adjusted[..., 1] + self.high_ds_gate_boost * high_ds
        return adjusted

    def _apply_high_ds_hr_spectral_prior(self, hr_logits: torch.Tensor | None, ctrl_feat: torch.Tensor | None, meta=None) -> torch.Tensor | None:
        if hr_logits is None:
            return hr_logits
        strength = float(getattr(self, 'high_ds_hr_spectral_prior_strength', 0.0))
        if strength == 0.0:
            return hr_logits
        if ctrl_feat is None or meta is None:
            return hr_logits
        feat_idx = int(getattr(self, 'high_ds_hr_spectral_feature_index', 13))
        if ctrl_feat.size(-1) <= feat_idx:
            return hr_logits
        bsz, pred_len = hr_logits.shape[:2]
        high_ds = self._build_high_ds_mask(meta=meta, bsz=bsz, pred_len=pred_len, device=hr_logits.device, dtype=hr_logits.dtype)
        if high_ds is None:
            return hr_logits
        if high_ds.dim() == 1:
            high_ds = high_ds.view(-1, 1).expand(-1, pred_len)
        elif high_ds.dim() == 2 and high_ds.size(1) == 1:
            high_ds = high_ds.expand(-1, pred_len)
        if high_ds.shape != hr_logits.shape[:2]:
            return hr_logits
        if torch.sum(high_ds).item() <= 0:
            return hr_logits
        spectral_value = ctrl_feat[..., feat_idx].to(dtype=hr_logits.dtype)
        threshold = float(getattr(self, 'high_ds_hr_spectral_threshold', 1.05))
        de_like = (spectral_value >= threshold).to(dtype=hr_logits.dtype)
        abc_like = 1.0 - de_like
        high_ds = high_ds.to(dtype=hr_logits.dtype)
        adjusted = hr_logits.clone()
        adjusted[..., 0] = adjusted[..., 0] + strength * high_ds * de_like
        adjusted[..., 1] = adjusted[..., 1] + strength * high_ds * abc_like
        return adjusted

    def _compose_two_stage_logits(self, gate_logits: torch.Tensor, hr_logits: torch.Tensor) -> torch.Tensor:
        gate_logp = F.log_softmax(gate_logits, dim=-1)
        hr_logp = F.log_softmax(hr_logits, dim=-1)
        skip_logit = torch.full_like(gate_logp[..., :1], -1000000000.0)
        low_logit = gate_logp[..., 0:1]
        high_logit = gate_logp[..., 1:2] + hr_logp[..., 0:1]
        refresh_logit = gate_logp[..., 1:2] + hr_logp[..., 1:2]
        return torch.cat([skip_logit, low_logit, high_logit, refresh_logit], dim=-1)

    def _two_stage_action_probs(self, gate_logits: torch.Tensor, hr_logits: torch.Tensor, hard: bool, tau: float, meta: dict | None=None) -> torch.Tensor:
        if gate_logits is None or hr_logits is None:
            raise ValueError('Two-stage action construction requires gate_logits and hr_logits.')
        if gate_logits.shape[:-1] != hr_logits.shape[:-1]:
            raise ValueError(f'gate/hr shape mismatch: gate_logits.shape={gate_logits.shape!r} vs hr_logits.shape={hr_logits.shape!r}')
        if gate_logits.size(-1) != 2 or hr_logits.size(-1) != 2:
            raise ValueError(f'Expected gate/hr last dim = 2, got gate_logits.shape={gate_logits.shape!r} and hr_logits.shape={hr_logits.shape!r}')
        bsz, pred_len = gate_logits.shape[:2]
        if hard:
            gate_prob = torch.softmax(gate_logits, dim=-1)
            hr_prob = torch.softmax(hr_logits, dim=-1)
            refresh_threshold = torch.full((bsz, pred_len), float(self.two_stage_gate_threshold_refresh), device=gate_logits.device, dtype=gate_logits.dtype)
            refresh_choice = hr_prob[..., 1] > refresh_threshold
            threshold_high = torch.full((bsz, pred_len), float(self.two_stage_gate_threshold_high), device=gate_logits.device, dtype=gate_logits.dtype)
            threshold_refresh = torch.full((bsz, pred_len), float(self.two_stage_gate_threshold_refresh), device=gate_logits.device, dtype=gate_logits.dtype)
            gate_threshold = torch.where(refresh_choice, threshold_refresh, threshold_high)
            if self.use_non_high_ds_eval_calibration and meta is not None:
                high_ds = self._build_high_ds_mask(meta=meta, bsz=bsz, pred_len=pred_len, device=gate_logits.device, dtype=gate_logits.dtype)
                if high_ds is not None:
                    if high_ds.dim() == 1:
                        high_ds = high_ds.view(-1, 1).expand(-1, pred_len)
                    elif high_ds.dim() == 2 and high_ds.size(1) == 1:
                        high_ds = high_ds.expand(-1, pred_len)
                    if high_ds.shape == gate_threshold.shape:
                        ds_value = meta.get('ds_ns', None) if isinstance(meta, dict) else None
                        if ds_value is None and isinstance(meta, dict):
                            ds_value = meta.get('ds', None)
                        if ds_value is not None:
                            if hasattr(self.controller, '_to_1d_tensor'):
                                ds_1d = self.controller._to_1d_tensor(ds_value, bsz, gate_logits.device, torch.float32, default_value=0.0)
                            else:
                                ds_1d = torch.as_tensor(ds_value, device=gate_logits.device, dtype=torch.float32).reshape(-1)
                                if ds_1d.numel() == 1:
                                    ds_1d = ds_1d.expand(bsz)
                                elif ds_1d.numel() != bsz:
                                    ds_1d = ds_1d[:bsz]
                            max_abs = ds_1d.detach().abs().max().item() if ds_1d.numel() > 0 else 0.0
                            ds_ns = ds_1d * 1000000000.0 if max_abs < 0.001 else ds_1d
                            high_ds = (ds_ns >= self.non_high_ds_threshold_ns).to(device=gate_logits.device, dtype=gate_logits.dtype).view(bsz, 1).expand(bsz, pred_len)
                        non_high_mask = high_ds <= 0.5
                        non_high_gate = torch.full_like(gate_threshold, float(self.non_high_ds_gate_threshold))
                        non_high_refresh = torch.full_like(refresh_threshold, float(self.non_high_ds_refresh_threshold))
                        gate_threshold = torch.where(non_high_mask, non_high_gate, gate_threshold)
                        refresh_threshold = torch.where(non_high_mask, non_high_refresh, refresh_threshold)
                        refresh_choice = hr_prob[..., 1] > refresh_threshold
            high_budget = gate_prob[..., 1] > gate_threshold
            action_probs = torch.zeros(bsz, pred_len, 4, device=gate_logits.device, dtype=gate_logits.dtype)
            low_mask = ~high_budget
            high_mask = high_budget & ~refresh_choice
            refresh_mask = high_budget & refresh_choice
            action_probs[..., 1] = low_mask.to(action_probs.dtype)
            action_probs[..., 2] = high_mask.to(action_probs.dtype)
            action_probs[..., 3] = refresh_mask.to(action_probs.dtype)
            return action_probs
        tau = max(float(tau), 1e-06)
        if self.train_route_mode == 'st_argmax':
            gate_probs = self._straight_through_argmax(gate_logits, tau=tau)
            hr_probs = self._straight_through_argmax(hr_logits, tau=tau)
        elif self.train_route_mode == 'hard_gumbel':
            gate_probs = sample_actions_gumbel(gate_logits, temperature=tau, hard=self.train_hard_gumbel)
            hr_probs = sample_actions_gumbel(hr_logits, temperature=tau, hard=self.train_hard_gumbel)
        elif self.train_route_mode == 'soft':
            gate_probs = sample_actions_gumbel(gate_logits, temperature=tau, hard=False)
            hr_probs = sample_actions_gumbel(hr_logits, temperature=tau, hard=False)
        else:
            raise ValueError(f"Unsupported train_route_mode={self.train_route_mode}. Expected one of ['st_argmax', 'hard_gumbel', 'soft']")
        action_probs = torch.zeros(bsz, pred_len, 4, device=gate_logits.device, dtype=gate_logits.dtype)
        action_probs[..., 1] = gate_probs[..., 0]
        action_probs[..., 2] = gate_probs[..., 1] * hr_probs[..., 0]
        action_probs[..., 3] = gate_probs[..., 1] * hr_probs[..., 1]
        action_probs = action_probs / action_probs.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        return action_probs

    def _route(self, hist: torch.Tensor, meta: dict | None=None, hard: bool=False):
        pred_base = self._predict_base(hist, meta=meta)
        ctrl_feat = compute_temporal_features(hist, pred_base)
        ctrl_feat = self._match_controller_feature_dim(ctrl_feat)
        logits = self.controller(ctrl_feat, meta=meta, target_avg_budget=self.target_avg_budget)
        gate_logits = getattr(self.controller, 'last_gate_logits', None)
        hr_logits = getattr(self.controller, 'last_hr_logits', None)
        is_two_stage_router = self.use_two_stage_loss and gate_logits is not None and (hr_logits is not None)
        if is_two_stage_router:
            gate_logits = self._apply_high_ds_gate_prior(gate_logits, meta=meta)
            hr_logits = self._apply_high_ds_hr_spectral_prior(hr_logits=hr_logits, meta=meta, ctrl_feat=ctrl_feat)
            logits = self._compose_two_stage_logits(gate_logits, hr_logits)
        if self.disable_skip_action:
            logits = logits.clone()
            logits[..., 0] = -1000000000.0
        if hard:
            tau = 0.0
            if is_two_stage_router:
                action_probs = self._two_stage_action_probs(gate_logits=gate_logits, hr_logits=hr_logits, hard=True, tau=tau, meta=meta)
            else:
                action_probs = deterministic_actions(logits)
        else:
            tau = self._get_current_tau()
            if is_two_stage_router:
                action_probs = self._two_stage_action_probs(gate_logits=gate_logits, hr_logits=hr_logits, hard=False, tau=tau, meta=meta)
            elif self.train_route_mode == 'st_argmax':
                action_probs = self._straight_through_argmax(logits, tau=tau)
            elif self.train_route_mode == 'hard_gumbel':
                action_probs = sample_actions_gumbel(logits, temperature=tau, hard=self.train_hard_gumbel)
            elif self.train_route_mode == 'soft':
                action_probs = sample_actions_gumbel(logits, temperature=tau, hard=False)
            else:
                raise ValueError(f"Unsupported train_route_mode={self.train_route_mode}. Expected one of ['st_argmax', 'hard_gumbel', 'soft']")
        action_probs = torch.nan_to_num(action_probs, nan=0.0, posinf=0.0, neginf=0.0)
        return (pred_base, ctrl_feat, logits, action_probs, tau, gate_logits, hr_logits)

    def _compute_qos_penalty(self, final_hat: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        step_mse = (final_hat - target).pow(2).mean(dim=-1)
        qos_penalty = torch.relu(step_mse - self.qos_threshold).mean()
        return qos_penalty

    def _build_oracle_actions(self, pred_base: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        residual = target - pred_base
        difficulty = residual.pow(2).mean(dim=-1)
        flat = difficulty.reshape(-1)
        q0 = torch.quantile(flat, self.oracle_quantiles[0])
        q1 = torch.quantile(flat, self.oracle_quantiles[1])
        q2 = torch.quantile(flat, self.oracle_quantiles[2])
        oracle = torch.zeros_like(difficulty, dtype=torch.long)
        oracle = torch.where(difficulty >= q0, torch.ones_like(oracle), oracle)
        oracle = torch.where(difficulty >= q1, torch.full_like(oracle, 2), oracle)
        oracle = torch.where(difficulty >= q2, torch.full_like(oracle, 3), oracle)
        if self.disable_skip_action:
            oracle = oracle.clamp_min(1)
        return oracle

    def _build_cost_teacher_actions(self, candidates: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if candidates.dim() != 4:
            raise ValueError(f'Expected candidates [B,L,A,D], got {candidates.shape}')
        if target.dim() != 3:
            raise ValueError(f'Expected target [B,L,D], got {target.shape}')
        if candidates.shape[0] != target.shape[0] or candidates.shape[1] != target.shape[1]:
            raise ValueError(f'Candidate/target batch-time mismatch: candidates.shape={candidates.shape!r} vs target.shape={target.shape!r}')
        diff = candidates - target.unsqueeze(2)
        err_power = diff.pow(2).sum(dim=-1)
        true_power = target.pow(2).sum(dim=-1, keepdim=True).clamp_min(1e-12)
        nmse_by_action = err_power / true_power
        budget_cost = self.cost_teacher_budget_lambda * self.rate_values.view(1, 1, -1)
        penalty = torch.tensor([self.cost_teacher_skip_penalty, self.cost_teacher_low_penalty, self.cost_teacher_high_penalty, self.cost_teacher_refresh_penalty], device=candidates.device, dtype=candidates.dtype).view(1, 1, -1)
        total_cost = nmse_by_action + budget_cost + penalty
        if self.disable_skip_action:
            total_cost = total_cost.clone()
            total_cost[..., 0] = 1000000000.0
        teacher = torch.argmin(total_cost, dim=-1).long()
        return teacher

    def _compute_expert_pretrain_losses(self, expert_out: dict, target: torch.Tensor):
        low_hat = expert_out['low_hat']
        high_hat = expert_out['high_hat']
        refresh_hat = expert_out['refresh_hat']
        loss_low = self.criterion(low_hat, target)
        loss_high = self.criterion(high_hat, target)
        loss_refresh = self.criterion(refresh_hat, target)
        total_loss = self.lambda_low * loss_low + self.lambda_high * loss_high + self.lambda_refresh * loss_refresh
        aux = {'loss_low': loss_low.detach(), 'loss_high': loss_high.detach(), 'loss_refresh': loss_refresh.detach()}
        return (total_loss, aux)

    def _compute_two_stage_teacher_loss(self, gate_logits: torch.Tensor, hr_logits: torch.Tensor, oracle_actions: torch.Tensor | None=None, soft_teacher_probs: torch.Tensor | None=None) -> torch.Tensor:
        zero = torch.tensor(0.0, device=gate_logits.device)
        if soft_teacher_probs is not None:
            p_low = soft_teacher_probs[..., 1]
            p_high = soft_teacher_probs[..., 2]
            p_refresh = soft_teacher_probs[..., 3]
            gate_target = torch.stack([p_low, p_high + p_refresh], dim=-1)
            gate_target = gate_target / gate_target.sum(dim=-1, keepdim=True).clamp_min(1e-12)
            log_gate = F.log_softmax(gate_logits, dim=-1)
            loss_gate = -(gate_target * log_gate).sum(dim=-1).mean()
            hr_mass = (p_high + p_refresh).clamp_min(0.0)
            hr_target = torch.stack([p_high, p_refresh], dim=-1)
            hr_target = hr_target / hr_target.sum(dim=-1, keepdim=True).clamp_min(1e-12)
            log_hr = F.log_softmax(hr_logits, dim=-1)
            loss_hr_per_slot = -(hr_target * log_hr).sum(dim=-1)
            denom = hr_mass.sum().clamp_min(1.0)
            loss_hr = (loss_hr_per_slot * hr_mass).sum() / denom
            return loss_gate + self.two_stage_hr_weight * loss_hr
        if oracle_actions is not None:
            gate_labels = (oracle_actions >= 2).long()
            loss_gate = F.cross_entropy(gate_logits.reshape(-1, 2), gate_labels.reshape(-1))
            high_budget_mask = gate_labels.bool()
            if high_budget_mask.any():
                hr_labels = (oracle_actions[high_budget_mask] == 3).long()
                loss_hr = F.cross_entropy(hr_logits[high_budget_mask], hr_labels)
            else:
                loss_hr = zero
            return loss_gate + self.two_stage_hr_weight * loss_hr
        return zero

    def _compute_losses(self, pred_base: torch.Tensor, final_hat: torch.Tensor, target: torch.Tensor, action_probs: torch.Tensor, logits: torch.Tensor | None=None, oracle_actions: torch.Tensor | None=None, soft_teacher_probs=None, gate_logits=None, hr_logits=None):
        loss_rec = self.criterion(final_hat, target)
        loss_base = self.criterion(pred_base, target)
        exp_budget = expected_budget(action_probs, self.rate_values)
        avg_budget = exp_budget.mean()
        peak_violation = torch.relu(exp_budget - self.peak_budget).mean()
        loss_avg = torch.abs(avg_budget - self.target_avg_budget)
        loss_peak = peak_violation
        loss_qos = self._compute_qos_penalty(final_hat, target)
        loss_ce = torch.tensor(0.0, device=final_hat.device)
        if self.use_soft_cost_teacher:
            ce_weight = self.soft_cost_teacher_kl_weight
        elif self.use_cost_teacher:
            ce_weight = self.cost_teacher_ce_weight
        else:
            ce_weight = self.lambda_ce
        if self.use_two_stage_loss and gate_logits is not None and (hr_logits is not None):
            loss_ce = self._compute_two_stage_teacher_loss(gate_logits=gate_logits, hr_logits=hr_logits, oracle_actions=oracle_actions, soft_teacher_probs=soft_teacher_probs)
        elif self.use_soft_cost_teacher and logits is not None and (soft_teacher_probs is not None):
            log_probs = F.log_softmax(logits, dim=-1)
            loss_ce = -(soft_teacher_probs * log_probs).sum(dim=-1).mean()
        elif (self.use_oracle_ce or self.use_cost_teacher) and logits is not None and (oracle_actions is not None):
            ce_weight_tensor = self.cost_teacher_class_weights if self.use_cost_teacher else None
            loss_ce = F.cross_entropy(logits.reshape(-1, logits.size(-1)), oracle_actions.reshape(-1), weight=ce_weight_tensor)
        total_loss = self.lambda_rec * loss_rec + self.lambda_base * loss_base + self.lambda_avg * loss_avg + self.lambda_peak * loss_peak + self.lambda_qos * loss_qos + ce_weight * loss_ce
        aux = {'loss_rec': loss_rec.detach(), 'loss_base': loss_base.detach(), 'loss_avg': loss_avg.detach(), 'loss_peak': loss_peak.detach(), 'loss_qos': loss_qos.detach(), 'loss_ce': loss_ce.detach(), 'avg_budget': avg_budget.detach(), 'peak_violation': peak_violation.detach(), 'step_budget_mean': exp_budget.mean(dim=0).detach(), 'skip_ratio': action_probs[..., 0].mean().detach(), 'low_ratio': action_probs[..., 1].mean().detach(), 'high_ratio': action_probs[..., 2].mean().detach(), 'refresh_ratio': action_probs[..., 3].mean().detach()}
        return (total_loss, aux)

    def _route_mode_code(self) -> float:
        if self.train_route_mode == 'soft':
            return 0.0
        if self.train_route_mode == 'hard_gumbel':
            return 1.0
        if self.train_route_mode == 'st_argmax':
            return 2.0
        return -1.0

    def _log_step_metrics(self, stage: str, aux: dict, tau: float):
        self.log(f'{stage}_loss_rec', aux['loss_rec'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_loss_base', aux['loss_base'], on_step=False, on_epoch=True, prog_bar=True, logger=True)
        self.log(f'{stage}_loss_ce', aux['loss_ce'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_avg_budget', aux['avg_budget'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_peak_violation', aux['peak_violation'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_skip_ratio', aux['skip_ratio'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_low_ratio', aux['low_ratio'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_high_ratio', aux['high_ratio'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_refresh_ratio', aux['refresh_ratio'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        step_budget_mean = aux['step_budget_mean']
        for step_idx in range(step_budget_mean.numel()):
            self.log(f'{stage}_budget_t{step_idx}', step_budget_mean[step_idx], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        if stage == 'train':
            self.log('train_tau', float(tau), on_step=False, on_epoch=True, prog_bar=False, logger=True)
            self.log('train_route_mode_code', self._route_mode_code(), on_step=False, on_epoch=True, prog_bar=False, logger=True)

    def _log_expert_pretrain_metrics(self, stage: str, aux: dict):
        self.log(f'{stage}_loss_low', aux['loss_low'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_loss_high', aux['loss_high'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        self.log(f'{stage}_loss_refresh', aux['loss_refresh'], on_step=False, on_epoch=True, prog_bar=False, logger=True)
        if stage == 'train':
            self.log('train_expert_pretrain_mode', 1.0, on_step=False, on_epoch=True, prog_bar=False, logger=True)

    def forward(self, hist: torch.Tensor, meta: dict | None=None, hard: bool=False):
        pred_base, ctrl_feat, logits, action_probs, tau, gate_logits, hr_logits = self._route(hist, meta=meta, hard=hard)
        force_action = os.environ.get('ADAPTIVE_FORCE_ACTION', '').strip()
        if force_action.lower() not in ('', 'none', 'null'):
            action_idx = int(force_action)
            if action_idx < 0 or action_idx >= action_probs.size(-1):
                raise ValueError(f'ADAPTIVE_FORCE_ACTION must be in [0, {action_probs.size(-1) - 1}], got {action_idx}')
            forced = torch.zeros_like(action_probs)
            forced[..., action_idx] = 1.0
            action_probs = forced
        return {'pred_base': pred_base, 'ctrl_feat': ctrl_feat, 'logits': logits, 'action_probs': action_probs, 'tau': tau, 'gate_logits': gate_logits, 'hr_logits': hr_logits}

    def _shared_step_expert_pretrain(self, batch, stage: str):
        hist, target, meta = self._extract_batch(batch)
        pred_base = self._predict_base(hist, meta=meta)
        _, expert_out = self._build_candidates(pred_base, target)
        total_loss, aux = self._compute_expert_pretrain_losses(expert_out, target)
        self.log(f'{stage}_loss', total_loss, on_step=False, on_epoch=True, prog_bar=True, logger=True)
        self._log_expert_pretrain_metrics(stage, aux)
        outputs = {'loss': total_loss, 'pred_base': pred_base.detach(), 'target': target.detach(), 'low_hat': expert_out['low_hat'].detach(), 'high_hat': expert_out['high_hat'].detach(), 'refresh_hat': expert_out['refresh_hat'].detach(), 'residual': expert_out['residual'].detach(), 'meta': meta}
        return outputs

    def _shared_step_routing(self, batch, stage: str):
        hist, target, meta = self._extract_batch(batch)
        hard = stage != 'train' and self.hard_in_eval
        out = self.forward(hist, meta=meta, hard=hard)
        pred_base = out['pred_base']
        logits = out['logits']
        action_probs = out['action_probs']
        tau = out['tau']
        gate_logits = out.get('gate_logits', None)
        hr_logits = out.get('hr_logits', None)
        candidates, expert_out = self._build_candidates(pred_base, target)
        final_hat = (action_probs.unsqueeze(-1) * candidates).sum(dim=2)
        oracle_actions = None
        soft_teacher_probs = None
        if stage == 'train':
            if self.use_soft_cost_teacher:
                soft_teacher_probs = self._build_soft_cost_teacher_probs(candidates.detach(), target.detach())
            elif self.use_cost_teacher:
                oracle_actions = self._build_cost_teacher_actions(candidates.detach(), target.detach())
            elif self.use_oracle_ce:
                oracle_actions = self._build_oracle_actions(pred_base.detach(), target.detach())
        total_loss, aux = self._compute_losses(pred_base=pred_base, final_hat=final_hat, target=target, action_probs=action_probs, logits=logits if stage == 'train' else None, oracle_actions=oracle_actions, soft_teacher_probs=soft_teacher_probs, gate_logits=gate_logits if stage == 'train' else None, hr_logits=hr_logits if stage == 'train' else None)
        self.log(f'{stage}_loss', total_loss, on_step=False, on_epoch=True, prog_bar=True, logger=True)
        self._log_step_metrics(stage, aux, tau)
        outputs = {'loss': total_loss, 'pred_base': pred_base.detach(), 'final_hat': final_hat.detach(), 'target': target.detach(), 'logits': logits.detach(), 'action_probs': action_probs.detach(), 'candidates': candidates.detach(), 'residual': expert_out['residual'].detach(), 'meta': meta}
        if oracle_actions is not None:
            outputs['oracle_actions'] = oracle_actions.detach()
        return outputs

    def _shared_step(self, batch, stage: str):
        if self.expert_pretrain_mode:
            return self._shared_step_expert_pretrain(batch, stage)
        return self._shared_step_routing(batch, stage)

    def training_step(self, batch, batch_idx):
        outputs = self._shared_step(batch, stage='train')
        return outputs['loss']

    def validation_step(self, batch, batch_idx):
        outputs = self._shared_step(batch, stage='val')
        return outputs['loss']

    def test_step(self, batch, batch_idx):
        outputs = self._shared_step(batch, stage='test')
        return outputs['loss']

    @torch.no_grad()
    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        hist, target, meta = self._extract_batch(batch)
        if self.expert_pretrain_mode:
            pred_base = self._predict_base(hist, meta=meta)
            _, expert_out = self._build_candidates(pred_base, target)
            return {'pred_base': pred_base, 'low_hat': expert_out['low_hat'], 'high_hat': expert_out['high_hat'], 'refresh_hat': expert_out['refresh_hat'], 'target': target, 'meta': meta}
        out = self.forward(hist, meta=meta, hard=True)
        pred_base = out['pred_base']
        action_probs = out['action_probs']
        action_idx = torch.argmax(action_probs, dim=-1)
        candidates, expert_out = self._build_candidates(pred_base, target)
        final_hat = (action_probs.unsqueeze(-1) * candidates).sum(dim=2)
        return {'pred_base': pred_base, 'final_hat': final_hat, 'action_probs': action_probs, 'action_idx': action_idx, 'target': target, 'residual': expert_out['residual'], 'meta': meta}
