import torch
import torch.nn as nn
import torch.nn.functional as F
ACTION_NAMES = ('skip', 'low', 'high', 'refresh')

def compute_temporal_features(hist: torch.Tensor, pred_base: torch.Tensor) -> torch.Tensor:
    if hist.dim() != 3 or pred_base.dim() != 3:
        raise ValueError(f'Expected hist/pred_base to be 3D tensors, got hist.shape={hist.shape!r} and pred_base.shape={pred_base.shape!r}')
    if hist.size(0) != pred_base.size(0) or hist.size(2) != pred_base.size(2):
        raise ValueError(f'Batch size / feature dim mismatch: hist.shape={hist.shape!r} vs pred_base.shape={pred_base.shape!r}')
    bsz, hist_len, feat_dim = hist.shape
    pred_len = pred_base.size(1)
    hist_abs = hist.abs()
    pred_abs = pred_base.abs()
    hist_energy = hist_abs.mean(dim=-1)
    if hist_len >= 2:
        hist_diff = hist[:, 1:, :] - hist[:, :-1, :]
        hist_speed = hist_diff.abs().mean(dim=-1)
        hist_speed_mean = hist_speed.mean(dim=1, keepdim=True)
        hist_speed_last = hist_speed[:, -1:].contiguous()
        hist_speed_std = hist_speed.std(dim=1, keepdim=True, unbiased=False)
    else:
        hist_speed_mean = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
        hist_speed_last = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
        hist_speed_std = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
    hist_energy_mean = hist_energy.mean(dim=1, keepdim=True)
    hist_energy_last = hist_energy[:, -1:].contiguous()
    hist_energy_std = hist_energy.std(dim=1, keepdim=True, unbiased=False)
    last_hist = hist[:, -1:, :]
    pred_energy = pred_abs.mean(dim=-1)
    pred_vs_hist = (pred_base - last_hist).abs().mean(dim=-1)
    pred_step_delta = torch.zeros_like(pred_energy)
    if pred_len >= 1:
        pred_step_delta[:, 0] = pred_vs_hist[:, 0]
    if pred_len >= 2:
        pred_step_delta[:, 1:] = (pred_base[:, 1:, :] - pred_base[:, :-1, :]).abs().mean(dim=-1)
    hist_energy_mean_expand = hist_energy_mean.expand(-1, pred_len)
    hist_energy_last_expand = hist_energy_last.expand(-1, pred_len)
    hist_energy_std_expand = hist_energy_std.expand(-1, pred_len)
    hist_speed_mean_expand = hist_speed_mean.expand(-1, pred_len)
    hist_speed_last_expand = hist_speed_last.expand(-1, pred_len)
    hist_speed_std_expand = hist_speed_std.expand(-1, pred_len)
    step_idx = torch.arange(pred_len, device=hist.device, dtype=hist.dtype)
    if pred_len > 1:
        step_idx = step_idx / (pred_len - 1)
    else:
        step_idx = torch.zeros_like(step_idx)
    step_idx = step_idx.unsqueeze(0).expand(bsz, -1)
    if feat_dim >= 2:
        hist_spec_diff = (hist[:, :, 1:] - hist[:, :, :-1]).abs().mean(dim=-1)
        pred_spec_diff = (pred_base[:, :, 1:] - pred_base[:, :, :-1]).abs().mean(dim=-1)
        hist_spec_diff_mean = hist_spec_diff.mean(dim=1, keepdim=True)
        hist_spec_diff_last = hist_spec_diff[:, -1:].contiguous()
        hist_spec_diff_std = hist_spec_diff.std(dim=1, keepdim=True, unbiased=False)
        pred_spec_diff_mean = pred_spec_diff
        pred_spectral_energy_std = pred_abs.std(dim=-1, unbiased=False)
        pred_hist_spec_gap = (pred_spec_diff_mean - hist_spec_diff_last.expand(-1, pred_len)).abs()
    else:
        zero_step = torch.zeros(bsz, pred_len, device=hist.device, dtype=hist.dtype)
        hist_spec_diff_mean = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
        hist_spec_diff_last = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
        hist_spec_diff_std = torch.zeros(bsz, 1, device=hist.device, dtype=hist.dtype)
        pred_spec_diff_mean = zero_step
        pred_spectral_energy_std = zero_step
        pred_hist_spec_gap = zero_step
    hist_spec_diff_mean_expand = hist_spec_diff_mean.expand(-1, pred_len)
    hist_spec_diff_last_expand = hist_spec_diff_last.expand(-1, pred_len)
    hist_spec_diff_std_expand = hist_spec_diff_std.expand(-1, pred_len)
    features = torch.stack([hist_energy_mean_expand, hist_energy_last_expand, hist_energy_std_expand, hist_speed_mean_expand, hist_speed_last_expand, hist_speed_std_expand, pred_energy, pred_vs_hist, pred_step_delta, step_idx, hist_spec_diff_mean_expand, hist_spec_diff_last_expand, hist_spec_diff_std_expand, pred_spec_diff_mean, pred_spectral_energy_std, pred_hist_spec_gap], dim=-1)
    return features

class BudgetController(nn.Module):

    def __init__(self, in_dim: int=10, hidden_dim: int=128, num_actions: int=4, dropout: float=0.1, use_layernorm: bool=True, use_context: bool=False, cm_vocab_size: int=16, cm_emb_dim: int=8, context_hidden_dim: int=32, budget_normalizer: float=256.0, context_scale_init: float=0.1, use_cm_embedding: bool=True, use_film_context: bool=False, context_mid_ds_threshold: float=0.5, context_high_ds_threshold: float=0.875):
        super().__init__()
        self.in_dim = in_dim
        self.num_actions = num_actions
        self.use_context = bool(use_context)
        self.cm_vocab_size = int(cm_vocab_size)
        self.cm_emb_dim = int(cm_emb_dim)
        self.context_hidden_dim = int(context_hidden_dim)
        self.budget_normalizer = float(budget_normalizer)
        self.use_cm_embedding = bool(use_cm_embedding)
        self.use_film_context = bool(use_film_context)
        self.context_mid_ds_threshold = float(context_mid_ds_threshold)
        self.context_high_ds_threshold = float(context_high_ds_threshold)
        if self.use_context:
            self.cm_embedding = nn.Embedding(self.cm_vocab_size, self.cm_emb_dim) if self.use_cm_embedding else None
            context_raw_dim = (self.cm_emb_dim if self.use_cm_embedding else 0) + 6
            context_out_dim = in_dim * 2 if self.use_film_context else in_dim
            self.context_encoder = nn.Sequential(nn.Linear(context_raw_dim, self.context_hidden_dim), nn.ReLU(inplace=True), nn.Linear(self.context_hidden_dim, context_out_dim))
            self.context_scale = nn.Parameter(torch.tensor(float(context_scale_init)))
        else:
            self.cm_embedding = None
            self.context_encoder = None
            self.context_scale = None
        layers = [nn.Linear(in_dim, hidden_dim), nn.ReLU(inplace=True)]
        if use_layernorm:
            layers.append(nn.LayerNorm(hidden_dim))
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU(inplace=True)]
        if use_layernorm:
            layers.append(nn.LayerNorm(hidden_dim))
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        layers.append(nn.Linear(hidden_dim, num_actions))
        self.net = nn.Sequential(*layers)

    @staticmethod
    def _to_1d_tensor(value, bsz: int, device, dtype, default_value: float=0.0):
        if value is None:
            x = torch.full((bsz,), default_value, device=device, dtype=dtype)
            return x
        if torch.is_tensor(value):
            x = value.to(device=device)
            if dtype is not None:
                x = x.to(dtype=dtype)
        else:
            x = torch.as_tensor(value, device=device, dtype=dtype)
        x = x.reshape(-1)
        if x.numel() == bsz:
            return x
        if x.numel() == 1:
            return x.expand(bsz)
        if bsz % x.numel() == 0:
            repeat = bsz // x.numel()
            return x.repeat_interleave(repeat)
        if x.numel() > bsz:
            return x[:bsz]
        pad = torch.full((bsz - x.numel(),), default_value, device=device, dtype=x.dtype)
        return torch.cat([x, pad], dim=0)

    @staticmethod
    def _normalize_ds(ds_value: torch.Tensor) -> torch.Tensor:
        ds_value = ds_value.float()
        max_abs = ds_value.abs().max().item() if ds_value.numel() > 0 else 0.0
        if max_abs < 0.001:
            return ds_value / 4e-07
        return ds_value / 400.0

    @staticmethod
    def _normalize_ms(ms_value: torch.Tensor) -> torch.Tensor:
        return ms_value.float() / 50.0

    def _build_context_raw(self, meta: dict | None, bsz: int, device, dtype, target_avg_budget: float | torch.Tensor | None=None) -> torch.Tensor | None:
        if not self.use_context or meta is None:
            return None
        raw_parts = []
        if self.use_cm_embedding:
            cm_id = meta.get('cm_id', None)
            cm_id = self._to_1d_tensor(cm_id, bsz, device, torch.long, default_value=0).long()
            cm_id = cm_id.clamp(min=0, max=self.cm_vocab_size - 1)
            raw_parts.append(self.cm_embedding(cm_id))
        ds_value = meta.get('ds_ns', None)
        if ds_value is None:
            ds_value = meta.get('ds', None)
        ds_value = self._to_1d_tensor(ds_value, bsz, device, torch.float32, default_value=0.0)
        ds_norm = self._normalize_ds(ds_value).clamp(min=0.0, max=1.5)
        ms_value = meta.get('ms', None)
        ms_value = self._to_1d_tensor(ms_value, bsz, device, torch.float32, default_value=0.0)
        ms_norm = self._normalize_ms(ms_value).clamp(min=0.0, max=2.0)
        if target_avg_budget is None:
            budget_value = torch.zeros(bsz, device=device, dtype=torch.float32)
        else:
            budget_value = self._to_1d_tensor(target_avg_budget, bsz, device, torch.float32, default_value=0.0)
        budget_norm = budget_value / max(self.budget_normalizer, 1e-06)
        mid_ds_flag = (ds_norm >= self.context_mid_ds_threshold).to(torch.float32)
        high_ds_flag = (ds_norm >= self.context_high_ds_threshold).to(torch.float32)
        ds_ms = ds_norm * ms_norm
        raw_parts.extend([ds_norm.unsqueeze(-1), ms_norm.unsqueeze(-1), ds_ms.unsqueeze(-1), mid_ds_flag.unsqueeze(-1), high_ds_flag.unsqueeze(-1), budget_norm.unsqueeze(-1)])
        return torch.cat(raw_parts, dim=-1).to(device=device, dtype=dtype)

    def _build_context_features(self, meta: dict | None, bsz: int, pred_len: int, device, dtype, target_avg_budget: float | torch.Tensor | None=None) -> torch.Tensor:
        if not self.use_context or meta is None:
            return torch.zeros(bsz, pred_len, self.in_dim, device=device, dtype=dtype)
        raw = self._build_context_raw(meta=meta, bsz=bsz, device=device, dtype=dtype, target_avg_budget=target_avg_budget)
        if raw is None:
            return torch.zeros(bsz, pred_len, self.in_dim, device=device, dtype=dtype)
        ctx = self.context_encoder(raw).to(dtype=dtype)
        if self.use_film_context:
            _, beta = ctx.chunk(2, dim=-1)
            ctx = beta
        ctx = ctx.unsqueeze(1).expand(bsz, pred_len, self.in_dim)
        return ctx

    def _apply_context_to_features(self, features: torch.Tensor, meta: dict | None, target_avg_budget: float | torch.Tensor | None=None) -> torch.Tensor:
        if not self.use_context or meta is None:
            return features
        bsz, pred_len, _ = features.shape
        raw = self._build_context_raw(meta=meta, bsz=bsz, device=features.device, dtype=features.dtype, target_avg_budget=target_avg_budget)
        if raw is None:
            return features
        ctx = self.context_encoder(raw).to(dtype=features.dtype)
        ctx = ctx.unsqueeze(1).expand(bsz, pred_len, -1)
        scale = self.context_scale.to(features.dtype)
        if self.use_film_context:
            gamma, beta = ctx.chunk(2, dim=-1)
            return features * (1.0 + scale * torch.tanh(gamma)) + scale * beta
        return features + scale * ctx

    def forward(self, features: torch.Tensor, meta: dict | None=None, target_avg_budget: float | torch.Tensor | None=None) -> torch.Tensor:
        if features.dim() != 3:
            raise ValueError(f'Expected 3D feature tensor, got features.shape={features.shape!r}')
        bsz, pred_len, feat_dim = features.shape
        if feat_dim != self.in_dim:
            raise ValueError(f'Expected feature dim {self.in_dim}, got {feat_dim}')
        features = self._apply_context_to_features(features=features, meta=meta, target_avg_budget=target_avg_budget)
        logits = self.net(features.reshape(bsz * pred_len, feat_dim))
        logits = logits.view(bsz, pred_len, self.num_actions)
        return logits

class TwoStageBudgetController(BudgetController):

    def __init__(self, in_dim: int=10, hidden_dim: int=128, num_actions: int=4, dropout: float=0.1, use_layernorm: bool=True, use_context: bool=False, cm_vocab_size: int=16, cm_emb_dim: int=8, context_hidden_dim: int=32, budget_normalizer: float=256.0, context_scale_init: float=0.1, use_cm_embedding: bool=True, use_film_context: bool=False, context_mid_ds_threshold: float=0.5, context_high_ds_threshold: float=0.875):
        if int(num_actions) != 4:
            raise ValueError('TwoStageBudgetController requires num_actions=4')
        super().__init__(in_dim=in_dim, hidden_dim=hidden_dim, num_actions=num_actions, dropout=dropout, use_layernorm=use_layernorm, use_context=use_context, cm_vocab_size=cm_vocab_size, cm_emb_dim=cm_emb_dim, context_hidden_dim=context_hidden_dim, budget_normalizer=budget_normalizer, context_scale_init=context_scale_init, use_cm_embedding=use_cm_embedding, use_film_context=use_film_context, context_mid_ds_threshold=context_mid_ds_threshold, context_high_ds_threshold=context_high_ds_threshold)
        layers = [nn.Linear(in_dim, hidden_dim), nn.ReLU(inplace=True)]
        if use_layernorm:
            layers.append(nn.LayerNorm(hidden_dim))
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU(inplace=True)]
        if use_layernorm:
            layers.append(nn.LayerNorm(hidden_dim))
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        self.shared = nn.Sequential(*layers)
        self.gate_head = nn.Linear(hidden_dim, 2)
        self.hr_head = nn.Linear(hidden_dim, 2)
        self.last_gate_logits = None
        self.last_hr_logits = None

    def forward(self, features: torch.Tensor, meta: dict | None=None, target_avg_budget: float | torch.Tensor | None=None) -> torch.Tensor:
        if features.dim() != 3:
            raise ValueError(f'Expected 3D feature tensor, got features.shape={features.shape!r}')
        bsz, pred_len, feat_dim = features.shape
        if feat_dim != self.in_dim:
            raise ValueError(f'Expected feature dim {self.in_dim}, got {feat_dim}')
        features = self._apply_context_to_features(features=features, meta=meta, target_avg_budget=target_avg_budget)
        flat = features.reshape(bsz * pred_len, feat_dim)
        hidden = self.shared(flat)
        gate_logits = self.gate_head(hidden).view(bsz, pred_len, 2)
        hr_logits = self.hr_head(hidden).view(bsz, pred_len, 2)
        self.last_gate_logits = gate_logits
        self.last_hr_logits = hr_logits
        gate_logp = F.log_softmax(gate_logits, dim=-1)
        hr_logp = F.log_softmax(hr_logits, dim=-1)
        skip_logit = torch.full_like(gate_logp[..., :1], -1000000000.0)
        low_logit = gate_logp[..., 0:1]
        high_logit = gate_logp[..., 1:2] + hr_logp[..., 0:1]
        refresh_logit = gate_logp[..., 1:2] + hr_logp[..., 1:2]
        logits = torch.cat([skip_logit, low_logit, high_logit, refresh_logit], dim=-1)
        return logits

def sample_actions_gumbel(logits: torch.Tensor, temperature: float=1.0, hard: bool=False) -> torch.Tensor:
    return F.gumbel_softmax(logits, tau=temperature, hard=hard, dim=-1)

def deterministic_actions(logits: torch.Tensor) -> torch.Tensor:
    action_idx = torch.argmax(logits, dim=-1)
    one_hot = F.one_hot(action_idx, num_classes=logits.size(-1)).to(logits.dtype)
    return one_hot

def expected_budget(probs: torch.Tensor, rate_values: torch.Tensor) -> torch.Tensor:
    if rate_values.dim() != 1:
        raise ValueError(f'Expected 1D rate_values, got rate_values.shape={rate_values.shape!r}')
    if probs.size(-1) != rate_values.numel():
        raise ValueError(f'Action dimension mismatch: probs.shape={probs.shape}, rate_values.shape={rate_values.shape}')
    rate_values = rate_values.to(device=probs.device, dtype=probs.dtype)
    return (probs * rate_values.view(1, 1, -1)).sum(dim=-1)

def action_indices_to_names(action_idx: torch.Tensor) -> list[list[str]]:
    action_idx = action_idx.detach().cpu()
    result = []
    for row in action_idx:
        result.append([ACTION_NAMES[int(i)] for i in row])
    return result
