from typing import Dict, Tuple
import torch
import torch.nn as nn

def _flatten_time(x: torch.Tensor):
    if x.dim() == 2:
        return (x, None)
    if x.dim() == 3:
        b, l, d = x.shape
        return (x.reshape(b * l, d), (b, l, d))
    raise ValueError(f'Expected tensor with shape [B,D] or [B,L,D], got {x.shape}')

def _restore_time(x: torch.Tensor, original_shape):
    if original_shape is None:
        return x
    b, l, d = original_shape
    return x.reshape(b, l, d)

class VectorAutoEncoder(nn.Module):

    def __init__(self, in_dim: int=600, bottleneck_dim: int=32, hidden_dims: Tuple[int, ...]=(256, 128), dropout: float=0.0, use_layernorm: bool=False):
        super().__init__()
        self.in_dim = int(in_dim)
        self.bottleneck_dim = int(bottleneck_dim)
        enc_layers = []
        prev = self.in_dim
        for h in hidden_dims:
            enc_layers.append(nn.Linear(prev, int(h)))
            enc_layers.append(nn.ReLU(inplace=True))
            if use_layernorm:
                enc_layers.append(nn.LayerNorm(int(h)))
            if dropout > 0:
                enc_layers.append(nn.Dropout(dropout))
            prev = int(h)
        enc_layers.append(nn.Linear(prev, self.bottleneck_dim))
        self.encoder = nn.Sequential(*enc_layers)
        dec_layers = []
        prev = self.bottleneck_dim
        for h in reversed(hidden_dims):
            dec_layers.append(nn.Linear(prev, int(h)))
            dec_layers.append(nn.ReLU(inplace=True))
            if use_layernorm:
                dec_layers.append(nn.LayerNorm(int(h)))
            if dropout > 0:
                dec_layers.append(nn.Dropout(dropout))
            prev = int(h)
        dec_layers.append(nn.Linear(prev, self.in_dim))
        self.decoder = nn.Sequential(*dec_layers)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        flat_x, original_shape = _flatten_time(x)
        z = self.encoder(flat_x)
        if original_shape is None:
            return z
        b, l, _ = original_shape
        return z.reshape(b, l, self.bottleneck_dim)

    def decode(self, z: torch.Tensor, original_shape=None) -> torch.Tensor:
        if z.dim() == 3:
            b, l, c = z.shape
            flat_z = z.reshape(b * l, c)
            out = self.decoder(flat_z)
            return out.reshape(b, l, self.in_dim)
        out = self.decoder(z)
        return _restore_time(out, original_shape)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        flat_x, original_shape = _flatten_time(x)
        z = self.encoder(flat_x)
        out = self.decoder(z)
        return _restore_time(out, original_shape)

class TemporalSpectralAutoEncoder(nn.Module):

    def __init__(self, in_dim: int=600, bottleneck_dim: int=32, hidden_dims: Tuple[int, ...]=(256, 128), dropout: float=0.0, use_layernorm: bool=False, pred_len: int=4, spectral_channels: int=16, temporal_hidden_dim: int=128, use_temporal: bool=True):
        super().__init__()
        if in_dim % 2 != 0:
            raise ValueError(f'in_dim must be even for real/imag split, got {in_dim}')
        self.in_dim = int(in_dim)
        self.bottleneck_dim = int(bottleneck_dim)
        self.pred_len = int(pred_len)
        self.num_subcarriers = self.in_dim // 2
        self.spectral_channels = int(spectral_channels)
        self.temporal_hidden_dim = int(temporal_hidden_dim)
        self.use_temporal = bool(use_temporal)
        c = self.spectral_channels
        h = self.temporal_hidden_dim
        self.spectral_encoder = nn.Sequential(nn.Conv1d(2, c, kernel_size=3, padding=1, bias=False), nn.BatchNorm1d(c), nn.GELU(), nn.Conv1d(c, c, kernel_size=5, padding=2, bias=False), nn.BatchNorm1d(c), nn.GELU())
        self.enc_proj = nn.Linear(c * self.num_subcarriers, h)
        self.enc_norm = nn.LayerNorm(h) if use_layernorm else nn.Identity()
        self.enc_drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        if self.use_temporal:
            self.temporal_encoder = nn.GRU(input_size=h, hidden_size=h, num_layers=1, batch_first=True, bidirectional=False)
            self.temporal_decoder = nn.GRU(input_size=h, hidden_size=h, num_layers=1, batch_first=True, bidirectional=False)
        else:
            self.temporal_encoder = None
            self.temporal_decoder = None
        self.to_z = nn.Linear(h, self.bottleneck_dim)
        self.from_z = nn.Linear(self.bottleneck_dim, h)
        self.dec_norm = nn.LayerNorm(h) if use_layernorm else nn.Identity()
        self.dec_drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.dec_proj = nn.Linear(h, c * self.num_subcarriers)
        self.spectral_decoder = nn.Sequential(nn.Conv1d(c, c, kernel_size=3, padding=1, bias=False), nn.BatchNorm1d(c), nn.GELU(), nn.Conv1d(c, 2, kernel_size=3, padding=1, bias=True))

    def _to_sequence(self, x: torch.Tensor):
        if x.dim() == 2:
            return (x.unsqueeze(1), True)
        if x.dim() == 3:
            return (x, False)
        raise ValueError(f'Expected [B,D] or [B,L,D], got {x.shape}')

    def _encode_sequence(self, x_seq: torch.Tensor) -> torch.Tensor:
        b, l, d = x_seq.shape
        x_ri = x_seq.reshape(b * l, 2, self.num_subcarriers)
        feat = self.spectral_encoder(x_ri)
        feat = feat.reshape(b, l, self.spectral_channels * self.num_subcarriers)
        feat = self.enc_proj(feat)
        feat = self.enc_norm(feat)
        feat = self.enc_drop(feat)
        if self.temporal_encoder is not None:
            feat, _ = self.temporal_encoder(feat)
        z = self.to_z(feat)
        return z

    def _decode_sequence(self, z_seq: torch.Tensor) -> torch.Tensor:
        b, l, _ = z_seq.shape
        feat = self.from_z(z_seq)
        feat = self.dec_norm(feat)
        feat = self.dec_drop(feat)
        if self.temporal_decoder is not None:
            feat, _ = self.temporal_decoder(feat)
        feat = self.dec_proj(feat)
        feat = feat.reshape(b * l, self.spectral_channels, self.num_subcarriers)
        out = self.spectral_decoder(feat)
        out = out.reshape(b, l, self.in_dim)
        return out

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        x_seq, squeeze = self._to_sequence(x)
        z = self._encode_sequence(x_seq)
        return z.squeeze(1) if squeeze else z

    def decode(self, z: torch.Tensor, original_shape=None) -> torch.Tensor:
        if z.dim() == 2:
            z_seq = z.unsqueeze(1)
            squeeze = True
        elif z.dim() == 3:
            z_seq = z
            squeeze = False
        else:
            raise ValueError(f'Expected [B,C] or [B,L,C], got {z.shape}')
        out = self._decode_sequence(z_seq)
        if original_shape is not None:
            return out.reshape(original_shape)
        return out.squeeze(1) if squeeze else out

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_seq, squeeze = self._to_sequence(x)
        z = self._encode_sequence(x_seq)
        out = self._decode_sequence(z)
        return out.squeeze(1) if squeeze else out

def _make_autoencoder(expert_type: str, in_dim: int, bottleneck_dim: int, hidden_dims: Tuple[int, ...], dropout: float, use_layernorm: bool, pred_len: int, spectral_channels: int, temporal_hidden_dim: int, use_temporal: bool):
    expert_type = str(expert_type).lower()
    if expert_type in ('vector', 'mlp', 'ae'):
        return VectorAutoEncoder(in_dim=in_dim, bottleneck_dim=bottleneck_dim, hidden_dims=hidden_dims, dropout=dropout, use_layernorm=use_layernorm)
    if expert_type in ('temporal_spectral', 'ts', 'temporal-spectral'):
        return TemporalSpectralAutoEncoder(in_dim=in_dim, bottleneck_dim=bottleneck_dim, hidden_dims=hidden_dims, dropout=dropout, use_layernorm=use_layernorm, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)
    raise ValueError(f'Unsupported expert_type={expert_type}. Expected one of: vector, temporal_spectral')

class ResidualExpert(nn.Module):

    def __init__(self, in_dim: int=600, bottleneck_dim: int=32, hidden_dims: Tuple[int, ...]=(256, 128), dropout: float=0.0, use_layernorm: bool=False, expert_type: str='vector', pred_len: int=4, spectral_channels: int=16, temporal_hidden_dim: int=128, use_temporal: bool=True):
        super().__init__()
        self.ae = _make_autoencoder(expert_type=expert_type, in_dim=in_dim, bottleneck_dim=bottleneck_dim, hidden_dims=hidden_dims, dropout=dropout, use_layernorm=use_layernorm, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)

    @property
    def bottleneck_dim(self) -> int:
        return self.ae.bottleneck_dim

    def encode(self, residual: torch.Tensor) -> torch.Tensor:
        return self.ae.encode(residual)

    def decode(self, z: torch.Tensor, original_shape: Tuple[int, ...]=None) -> torch.Tensor:
        return self.ae.decode(z, original_shape)

    def forward(self, residual: torch.Tensor) -> torch.Tensor:
        return self.ae(residual)

class FullRefreshExpert(nn.Module):

    def __init__(self, in_dim: int=600, bottleneck_dim: int=256, hidden_dims: Tuple[int, ...]=(512, 256), dropout: float=0.0, use_layernorm: bool=False, expert_type: str='vector', pred_len: int=4, spectral_channels: int=16, temporal_hidden_dim: int=128, use_temporal: bool=True):
        super().__init__()
        self.ae = _make_autoencoder(expert_type=expert_type, in_dim=in_dim, bottleneck_dim=bottleneck_dim, hidden_dims=hidden_dims, dropout=dropout, use_layernorm=use_layernorm, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)

    @property
    def bottleneck_dim(self) -> int:
        return self.ae.bottleneck_dim

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.ae.encode(x)

    def decode(self, z: torch.Tensor, original_shape: Tuple[int, ...]=None) -> torch.Tensor:
        return self.ae.decode(z, original_shape)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.ae(x)

class ExpertBank(nn.Module):

    def __init__(self, in_dim: int=600, low_bottleneck_dim: int=32, high_bottleneck_dim: int=128, full_bottleneck_dim: int=256, low_hidden_dims: Tuple[int, ...]=(256, 128), high_hidden_dims: Tuple[int, ...]=(256, 128), full_hidden_dims: Tuple[int, ...]=(512, 256), dropout: float=0.0, use_layernorm: bool=False, expert_type: str='vector', pred_len: int=4, spectral_channels: int=16, temporal_hidden_dim: int=128, use_temporal: bool=True):
        super().__init__()
        self.expert_type = str(expert_type)
        self.in_dim = int(in_dim)
        self.low_expert = ResidualExpert(in_dim=in_dim, bottleneck_dim=low_bottleneck_dim, hidden_dims=low_hidden_dims, dropout=dropout, use_layernorm=use_layernorm, expert_type=expert_type, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)
        self.high_expert = ResidualExpert(in_dim=in_dim, bottleneck_dim=high_bottleneck_dim, hidden_dims=high_hidden_dims, dropout=dropout, use_layernorm=use_layernorm, expert_type=expert_type, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)
        self.full_expert = FullRefreshExpert(in_dim=in_dim, bottleneck_dim=full_bottleneck_dim, hidden_dims=full_hidden_dims, dropout=dropout, use_layernorm=use_layernorm, expert_type=expert_type, pred_len=pred_len, spectral_channels=spectral_channels, temporal_hidden_dim=temporal_hidden_dim, use_temporal=use_temporal)

    def forward(self, pred_base: torch.Tensor, target: torch.Tensor) -> Dict[str, torch.Tensor]:
        if pred_base.shape != target.shape:
            raise ValueError(f'pred_base and target must have the same shape, got pred_base.shape={pred_base.shape!r} vs target.shape={target.shape!r}')
        residual = target - pred_base
        low_residual_hat = self.low_expert(residual)
        high_residual_hat = self.high_expert(residual)
        refresh_hat = self.full_expert(target)
        skip_hat = pred_base
        low_hat = pred_base + low_residual_hat
        high_hat = pred_base + high_residual_hat
        return {'skip_hat': skip_hat, 'low_hat': low_hat, 'high_hat': high_hat, 'refresh_hat': refresh_hat, 'residual': residual, 'low_residual_hat': low_residual_hat, 'high_residual_hat': high_residual_hat}

    def get_rate_dict(self) -> Dict[str, int]:
        return {'skip': 0, 'low': self.low_expert.bottleneck_dim, 'high': self.high_expert.bottleneck_dim, 'refresh': self.full_expert.bottleneck_dim}
