import torch
import torch.nn as nn
from src.cp.config.config import ExperimentConfig
from src.cp.models.common.base import BaseCSIModel

class SEBlock1D(nn.Module):

    def __init__(self, channel, reduction=4):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(nn.Linear(channel, max(1, channel // reduction), bias=False), nn.ReLU(inplace=True), nn.Linear(max(1, channel // reduction), channel, bias=False), nn.Sigmoid())

    def forward(self, x):
        b, c, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1)
        return x * y.expand_as(x)

class LocalFrequencyContext(nn.Module):

    def __init__(self, features):
        super().__init__()
        self.features = features
        self.num_subcarriers = features // 2
        self.conv_k3 = nn.Conv1d(2, 4, kernel_size=3, padding=1, bias=False)
        self.conv_k5 = nn.Conv1d(2, 4, kernel_size=5, padding=2, bias=False)
        self.bn = nn.BatchNorm1d(8)
        self.act = nn.LeakyReLU(0.1, inplace=True)
        self.se = SEBlock1D(8, reduction=4)
        self.proj = nn.Conv1d(8, 2, kernel_size=1, bias=False)

    def forward(self, x):
        b_l, d = x.shape
        x_ri = x.view(b_l, 2, self.num_subcarriers)
        out3 = self.conv_k3(x_ri)
        out5 = self.conv_k5(x_ri)
        out = torch.cat([out3, out5], dim=1)
        out = self.bn(out)
        out = self.act(out)
        out = self.se(out)
        out = self.proj(out)
        return out.view(b_l, d)

class ALC_RNNUnit(nn.Module):

    def __init__(self, features, input_size, hidden_size, num_layers=2, use_metadata_gate=True, cm_vocab_size=16, cm_emb_dim=8, meta_hidden_dim=16):
        super().__init__()
        self.features = features
        self.input_size = input_size
        self.use_metadata_gate = use_metadata_gate
        self.meta_hidden_dim = meta_hidden_dim
        self.global_encoder = nn.Linear(features, input_size)
        self.local_encoder = LocalFrequencyContext(features)
        self.local_proj = nn.Identity() if features == input_size else nn.Linear(features, input_size)
        self.cm_embedding = nn.Embedding(cm_vocab_size, cm_emb_dim)
        self.meta_proj = nn.Sequential(nn.Linear(cm_emb_dim + 2, meta_hidden_dim), nn.ReLU(inplace=True), nn.Linear(meta_hidden_dim, meta_hidden_dim), nn.ReLU(inplace=True))
        gate_in_dim = features + (meta_hidden_dim if use_metadata_gate else 0)
        self.local_gate = nn.Sequential(nn.Linear(gate_in_dim, 64, bias=True), nn.ReLU(inplace=True), nn.Linear(64, 1, bias=True), nn.Sigmoid())
        nn.init.constant_(self.local_gate[-2].bias, -2.0)
        self.rnn = nn.RNN(input_size, hidden_size, num_layers)
        self.decoder = nn.Linear(hidden_size, features)

    @staticmethod
    def _to_tensor(value, device, dtype=None):
        if value is None:
            return None
        if torch.is_tensor(value):
            return value.to(device=device, dtype=dtype) if dtype is not None else value.to(device=device)
        return torch.as_tensor(value, device=device, dtype=dtype)

    def _normalize_ds(self, ds_value: torch.Tensor) -> torch.Tensor:
        ds_value = ds_value.float()
        max_abs = ds_value.abs().max().item() if ds_value.numel() > 0 else 0.0
        if max_abs < 0.001:
            return ds_value / 4e-07
        return ds_value / 400.0

    def _normalize_ms(self, ms_value: torch.Tensor) -> torch.Tensor:
        ms_value = ms_value.float()
        return ms_value / 50.0

    def _build_meta_feature(self, meta: dict | None, L: int, B: int, device, dtype):
        if not self.use_metadata_gate or meta is None or len(meta) == 0:
            return torch.zeros(L * B, self.meta_hidden_dim, device=device, dtype=dtype)
        cm_id = meta.get('cm_id', None)
        cm_id = self._to_tensor(cm_id, device=device)
        if cm_id is None:
            cm_id = torch.zeros(B, device=device, dtype=torch.long)
        cm_id = cm_id.reshape(-1).long()
        if cm_id.numel() == 1:
            cm_id = cm_id.expand(B)
        elif cm_id.numel() != B:
            cm_id = cm_id[:B]
        cm_emb = self.cm_embedding(cm_id)
        ds_value = meta.get('ds_ns', None)
        if ds_value is None:
            ds_value = meta.get('ds', None)
        ds_value = self._to_tensor(ds_value, device=device, dtype=torch.float32)
        if ds_value is None:
            ds_value = torch.zeros(B, device=device, dtype=torch.float32)
        ds_value = ds_value.reshape(-1)
        if ds_value.numel() == 1:
            ds_value = ds_value.expand(B)
        elif ds_value.numel() != B:
            ds_value = ds_value[:B]
        ds_value = self._normalize_ds(ds_value).unsqueeze(-1)
        ms_value = meta.get('ms', None)
        ms_value = self._to_tensor(ms_value, device=device, dtype=torch.float32)
        if ms_value is None:
            ms_value = torch.zeros(B, device=device, dtype=torch.float32)
        ms_value = ms_value.reshape(-1)
        if ms_value.numel() == 1:
            ms_value = ms_value.expand(B)
        elif ms_value.numel() != B:
            ms_value = ms_value[:B]
        ms_value = self._normalize_ms(ms_value).unsqueeze(-1)
        meta_raw = torch.cat([cm_emb, ds_value, ms_value], dim=-1)
        meta_feat = self.meta_proj(meta_raw)
        meta_feat = meta_feat.unsqueeze(0).expand(L, B, self.meta_hidden_dim).reshape(L * B, self.meta_hidden_dim)
        return meta_feat.to(dtype=dtype)

    def forward(self, x, prev_hidden, meta: dict | None=None):
        L, B, _ = x.shape
        x_flat = x.reshape(L * B, -1)
        feat_global = self.global_encoder(x_flat)
        feat_local = self.local_encoder(x_flat)
        feat_local = self.local_proj(feat_local)
        if self.use_metadata_gate:
            meta_feat = self._build_meta_feature(meta=meta, L=L, B=B, device=x.device, dtype=x_flat.dtype)
            gate_input = torch.cat([x_flat, meta_feat], dim=-1)
        else:
            gate_input = x_flat
        gate = self.local_gate(gate_input)
        output = feat_global + gate * feat_local
        output = output.reshape(L, B, -1)
        output, cur_hidden = self.rnn(output, prev_hidden)
        output = output.reshape(L * B, -1)
        output = self.decoder(output)
        output = output.reshape(L, B, -1)
        return (output, cur_hidden)

class ALCRNN(nn.Module):

    def __init__(self, dim_data, rnn_hidden_dim, rnn_num_layers=2, pred_len=4, use_metadata_gate=True, cm_vocab_size=16, cm_emb_dim=8, meta_hidden_dim=16, *args, **kwargs):
        super().__init__()
        self.dim_data = dim_data
        self.rnn_hidden_dim = rnn_hidden_dim
        self.rnn_num_layers = rnn_num_layers
        self.pred_len = pred_len
        self.model = ALC_RNNUnit(features=dim_data, input_size=dim_data, hidden_size=rnn_hidden_dim, num_layers=rnn_num_layers, use_metadata_gate=use_metadata_gate, cm_vocab_size=cm_vocab_size, cm_emb_dim=cm_emb_dim, meta_hidden_dim=meta_hidden_dim)

    def train_pro(self, x, meta: dict | None=None):
        batch_size, seq_len, _ = x.shape
        prev_hidden = torch.zeros(self.rnn_num_layers, batch_size, self.rnn_hidden_dim, device=x.device)
        outputs = []
        for idx in range(seq_len + self.pred_len - 1):
            if idx < seq_len:
                input_step = x[:, idx:idx + 1, ...].permute(1, 0, 2).contiguous()
                output, prev_hidden = self.model(input_step, prev_hidden, meta=meta)
            else:
                output, prev_hidden = self.model(output, prev_hidden, meta=meta)
            if idx >= seq_len - 1:
                outputs.append(output)
        outputs = torch.cat(outputs, dim=0).permute(1, 0, 2).contiguous()
        return outputs

    def forward(self, x, meta: dict | None=None):
        return self.train_pro(x, meta=meta)

class ALCRNN_pl(BaseCSIModel):

    def __init__(self, config: ExperimentConfig, *args, **kwargs):
        super().__init__(optimizer_config=config.optimizer, scheduler_config=config.scheduler, loss_config=config.loss)
        self.name = 'ALC_RNN'
        self.is_separate_antennas = config.model.is_separate_antennas
        self.save_hyperparameters({'model': config.model})
        self.model = ALCRNN(**config.model.params)

    def __str__(self):
        return self.name

    def forward(self, x, meta: dict | None=None):
        return self.model(x, meta=meta)
