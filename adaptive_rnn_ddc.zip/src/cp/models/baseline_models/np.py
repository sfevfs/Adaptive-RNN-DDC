import torch.nn as nn
from src.utils.data_utils import PRED_LEN

class NOPREDICTMODEL(nn.Module):

    def __init__(self, pred_len=PRED_LEN, *args, **kwargs):
        super().__init__()
        self.is_separate_antennas = True
        self.name = 'NP'
        self.pred_len = pred_len

    def __str__(self) -> str:
        return self.name

    def forward(self, x):
        last_step = x[:, [-1], :]
        return last_step.repeat(1, self.pred_len, 1)
