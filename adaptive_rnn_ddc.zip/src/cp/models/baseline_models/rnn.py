import torch
import torch.nn as nn
from src.cp.config.config import ExperimentConfig
from src.cp.models.common.base import BaseCSIModel

class RNNUnit(nn.Module):

    def __init__(self, features, input_size, hidden_size, num_layers=2):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(features, input_size))
        self.rnn = nn.RNN(input_size, hidden_size, num_layers)
        self.decoder = nn.Sequential(nn.Linear(hidden_size, features))

    def forward(self, x, prev_hidden):
        L, B, _ = x.shape
        output = x.reshape(L * B, -1)
        output = self.encoder(output)
        output = output.reshape(L, B, -1)
        output, cur_hidden = self.rnn(output, prev_hidden)
        output = output.reshape(L * B, -1)
        output = self.decoder(output)
        output = output.reshape(L, B, -1)
        return (output, cur_hidden)

class RNN(nn.Module):

    def __init__(self, dim_data, rnn_hidden_dim, rnn_num_layers=2, pred_len=4, *args, **kwargs):
        super().__init__()
        self.dim_data = dim_data
        self.rnn_hidden_dim = rnn_hidden_dim
        self.rnn_num_layers = rnn_num_layers
        self.pred_len = pred_len
        self.model = RNNUnit(dim_data, dim_data, rnn_hidden_dim, num_layers=rnn_num_layers)

    def train_pro(self, x):
        BATCH_SIZE, seq_len, _ = x.shape
        prev_hidden = torch.zeros(self.rnn_num_layers, BATCH_SIZE, self.rnn_hidden_dim).to(x.device)
        outputs = []
        for idx in range(seq_len + self.pred_len - 1):
            if idx < seq_len:
                input_step = x[:, idx:idx + 1, ...].permute(1, 0, 2).contiguous()
                output, prev_hidden = self.model(input_step, prev_hidden)
            else:
                output, prev_hidden = self.model(output, prev_hidden)
            if idx >= seq_len - 1:
                outputs.append(output)
        outputs = torch.cat(outputs, dim=0).permute(1, 0, 2).contiguous()
        return outputs

    def forward(self, x):
        return self.train_pro(x)

class RNN_pl(BaseCSIModel):

    def __init__(self, config: ExperimentConfig, *args, **kwargs):
        super().__init__(optimizer_config=config.optimizer, scheduler_config=config.scheduler, loss_config=config.loss)
        self.name = 'RNN'
        self.is_separate_antennas = config.model.is_separate_antennas
        self.save_hyperparameters({'model': config.model})
        self.model = RNN(**config.model.params)

    def __str__(self):
        return self.name

    def forward(self, x):
        return self.model(x)
