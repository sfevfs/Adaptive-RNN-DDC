import logging
import lightning.pytorch as pl
import torch
from src.cp.config.config import LossConfig, OptimizerConfig, SchedulerConfig
from src.cp.loss.loss import LOSS
logger = logging.getLogger(__name__)

class BaseCSIModel(pl.LightningModule):

    def __init__(self, optimizer_config: OptimizerConfig, scheduler_config: SchedulerConfig, loss_config: LossConfig, **kwargs):
        super().__init__()
        self.save_hyperparameters()
        self.name = 'BaseModel'
        self.is_separate_antennas = True
        self._setup_loss()
        self.train_losses = []
        self.val_losses = []

    def _setup_loss(self):
        loss_cfg = self.hparams.loss_config
        self.criterion = getattr(LOSS, loss_cfg.name)(**loss_cfg.params)

    def forward(self, x):
        raise NotImplementedError('Forward method must be implemented by child class')

    def training_step(self, batch, batch_idx):
        hist, target = batch
        pred = self(hist)
        loss = self.criterion(pred, target)
        self.log('train_loss', loss, on_step=False, on_epoch=True, prog_bar=True, logger=True)
        return loss

    def validation_step(self, batch, batch_idx):
        hist, target = batch
        pred = self(hist)
        loss = self.criterion(pred, target)
        self.log('val_loss', loss, on_step=False, on_epoch=True, prog_bar=True, logger=True)
        return loss

    def configure_optimizers(self):
        optimizer_cfg = self.hparams.optimizer_config
        scheduler_cfg = self.hparams.scheduler_config
        optimizer_class = getattr(torch.optim, optimizer_cfg.name)
        valid_optimizer_params = self._filter_optimizer_params(optimizer_class, optimizer_cfg.params)
        optimizer = optimizer_class(self.parameters(), **valid_optimizer_params)
        scheduler = getattr(torch.optim.lr_scheduler, scheduler_cfg.name)(optimizer, **scheduler_cfg.params)
        return {'optimizer': optimizer, 'lr_scheduler': {'scheduler': scheduler, 'monitor': 'val_loss', 'interval': 'epoch', 'frequency': 1}}

    def _filter_optimizer_params(self, optimizer_class, params):
        import inspect
        signature = inspect.signature(optimizer_class.__init__)
        valid_param_names = set(signature.parameters.keys())
        valid_param_names.discard('self')
        valid_param_names.discard('params')
        filtered_params = {k: v for k, v in params.items() if k in valid_param_names}
        filtered_out = set(params.keys()) - set(filtered_params.keys())
        if filtered_out:
            logger.warning(f'Filtered out invalid {optimizer_class.__name__} parameters: {filtered_out}')
            logger.info(f'Valid {optimizer_class.__name__} parameters: {sorted(valid_param_names)}')
            logger.info(f'Using parameters: {filtered_params}')
        return filtered_params

    def on_train_start(self):
        total_params = sum((p.numel() for p in self.parameters()))
        trainable_params = sum((p.numel() for p in self.parameters() if p.requires_grad))
        self.log_dict({'total_parameters': total_params, 'trainable_parameters': trainable_params}, on_step=False, on_epoch=True)
        if self.logger is not None:
            self.logger.log_hyperparams(self.hparams)

    def on_train_epoch_end(self):
        if self.trainer.optimizers:
            current_lr = self.trainer.optimizers[0].param_groups[0]['lr']
            self.log('learning_rate', current_lr, on_epoch=True, logger=True)

    def predict_step(self, batch, batch_idx):
        hist, _ = batch if isinstance(batch, tuple) else (batch, None)
        return self(hist)
