import math
import torch

def gen_vanilla_noise_snr(H: torch.Tensor, SNR: float) -> torch.Tensor:
    if not H.is_complex():
        raise ValueError(f'H must be a complex tensor, got dtype={H.dtype}')
    sigma = 10 ** (-SNR / 10)
    power = torch.mean(torch.abs(H) ** 2)
    scale = math.sqrt(sigma / 2) * torch.sqrt(power)
    real_part = torch.randn(H.shape, dtype=H.real.dtype, device=H.device)
    imag_part = torch.randn(H.shape, dtype=H.imag.dtype, device=H.device)
    noise = torch.complex(real_part, imag_part) * scale
    return noise

def gen_phase_noise_nd(data: torch.Tensor, noise_degree: float=0.01) -> torch.Tensor:
    if not data.is_complex():
        raise ValueError(f'data must be a complex tensor, got dtype={data.dtype}')
    if noise_degree == 0:
        return torch.zeros_like(data)
    magnitude = torch.abs(data)
    phase = torch.angle(data)
    phase_noise = torch.randn_like(phase) * noise_degree
    new_phase = phase + phase_noise
    real_delta = magnitude * (torch.cos(new_phase) - torch.cos(phase))
    imag_delta = magnitude * (torch.sin(new_phase) - torch.sin(phase))
    phase_noise = torch.complex(real_delta, imag_delta)
    return phase_noise.to(data.dtype)

def gen_packagedrop_noise_nd(data: torch.Tensor, noise_degree: float=0.01) -> torch.Tensor:
    if noise_degree == 0:
        return torch.zeros_like(data)
    B, _, T, _ = data.shape
    drop_mask = torch.bernoulli(torch.full((B, T), noise_degree, device=data.device)).bool()
    mask_expanded = drop_mask.unsqueeze(1).unsqueeze(-1).expand_as(data)
    noisy_data = data.clone()
    noisy_data[mask_expanded] = 0.0
    noise = noisy_data - data
    return noise.to(data.dtype)

def gen_burst_noise_nd(data: torch.Tensor, noise_degree: float=0.01) -> torch.Tensor:
    B, N, T, K = data.shape
    burst_amplitude = 2 * noise_degree
    burst_length = 10
    burst_prob = 0.05 * noise_degree * 40
    noise = torch.zeros_like(data)
    if noise_degree == 0:
        return noise
    geo = torch.distributions.Geometric(burst_prob)
    burst_indicator = geo.sample((B,)) - 1
    burst_start = torch.randint(0, T, (B,), device=data.device)
    for b in range(B):
        if burst_indicator[b] < T:
            s = burst_start[b].item()
            e = min(s + burst_length, T)
            L = int(e - s)
            if L == 0:
                continue
            lin = torch.linspace(-1, 1, L, device=data.device)
            bell = burst_amplitude * torch.exp(-0.5 * lin ** 2)
            bell = bell.view(1, 1, L, 1)
            real = torch.randn((1, N, L, K), device=data.device) * bell
            imag = torch.randn((1, N, L, K), device=data.device) * bell
            burst = torch.complex(real, imag)
            noise[b, :, s:e, :] = burst
    return noise.to(data.dtype)
if __name__ == '__main__':
    fake_input_real = torch.randn(5, 32, 16, 300)
    fake_input_imag = torch.randn(5, 32, 16, 300)
    fake_input = torch.complex(fake_input_real, fake_input_imag)
    print('Testing burst noise generation...')
    noise = gen_burst_noise_nd(fake_input, 0.01)
    print(f'Burst noise shape: {noise.shape}')
    print(f'Burst noise dtype: {noise.dtype}')
    print('\nTesting other noise types...')
    vanilla_noise = gen_vanilla_noise_snr(fake_input, SNR=20.0)
    print(f'Vanilla noise shape: {vanilla_noise.shape}')
    phase_noise = gen_phase_noise_nd(fake_input, noise_degree=0.05)
    print(f'Phase noise shape: {phase_noise.shape}')
    drop_noise = gen_packagedrop_noise_nd(fake_input, noise_degree=0.02)
    print(f'Package drop noise shape: {drop_noise.shape}')
    print('\nAll noise generation functions tested successfully!')
