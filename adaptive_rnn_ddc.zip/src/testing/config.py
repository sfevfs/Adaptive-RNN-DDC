from itertools import product
import torch
from src.noise.noise_testing import Noise
from src.utils.data_utils import LIST_CHANNEL_MODEL, LIST_CHANNEL_MODEL_GEN, LIST_DELAY_SPREAD, LIST_DELAY_SPREAD_GEN, LIST_MIN_SPEED_TEST, LIST_MIN_SPEED_TEST_GEN
LIST_MODELS = ['RNN', 'NP', 'ALC_RNN', 'ADAPTIVE_RNN']
LIST_SCENARIOS = ['FDD']
LIST_NOISE_TYPES = ['phase', 'burst', 'vanilla', 'packagedrop']
BATCH_SIZE = 32
JOBS_PER_MODEL = 20

def create_all_combinations():
    noise = Noise()
    all_combinations = []
    for scenario in LIST_SCENARIOS:
        is_gen = False
        list_cm = LIST_CHANNEL_MODEL
        list_ds = LIST_DELAY_SPREAD
        list_ms = LIST_MIN_SPEED_TEST
        for noise_type in LIST_NOISE_TYPES:
            list_noise_degree = getattr(noise, f'list_{noise_type}_snr') if noise_type != 'packagedrop' else getattr(noise, f'list_{noise_type}_nd')
            for noise_degree, cm, ds, ms in product(list_noise_degree, list_cm, list_ds, list_ms):
                all_combinations.append((scenario, is_gen, noise_type, noise_degree, cm, ds, ms))
    for scenario in LIST_SCENARIOS:
        is_gen = True
        list_cm = LIST_CHANNEL_MODEL_GEN
        list_ds = LIST_DELAY_SPREAD_GEN
        list_ms = LIST_MIN_SPEED_TEST_GEN
        noise_type = 'vanilla'
        list_noise_degree = getattr(noise, f'list_{noise_type}_snr')
        for noise_degree, cm, ds, ms in product(list_noise_degree, list_cm, list_ds, list_ms):
            all_combinations.append((scenario, is_gen, noise_type, noise_degree, cm, ds, ms))
    return all_combinations

def slice_combinations(list_all_combs, slice_info):
    slice_idx, total_jobs = slice_info
    total_combs = len(list_all_combs)
    combs_per_job = total_combs // total_jobs
    remainder = total_combs % total_jobs
    if slice_idx < remainder:
        start_idx = slice_idx * (combs_per_job + 1)
        end_idx = start_idx + combs_per_job + 1
    else:
        start_idx = remainder * (combs_per_job + 1) + (slice_idx - remainder) * combs_per_job
        end_idx = start_idx + combs_per_job
    return list_all_combs[start_idx:end_idx]

def log_gpu_memory_usage(logger=None):
    try:
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / 1024 ** 3
            reserved = torch.cuda.memory_reserved() / 1024 ** 3
            max_allocated = torch.cuda.max_memory_allocated() / 1024 ** 3
            memory_info = f'GPU Memory - Allocated: {allocated:.2f}GB, Reserved: {reserved:.2f}GB, Max: {max_allocated:.2f}GB'
            if logger:
                logger.info(memory_info)
            else:
                print(memory_info)
        elif logger:
            logger.info('GPU not available')
        else:
            print('GPU not available')
    except ImportError:
        if logger:
            logger.warning('PyTorch not available for memory monitoring')
        else:
            print('PyTorch not available for memory monitoring')
