import os
import re
import logging
from pathlib import Path
import lightning.pytorch as pl
import torch
import yaml
import torch.nn as nn
from src.cp.models import PREDICTORS
from src.utils.dirs import DIR_WEIGHTS, DIR_OUTPUTS
logger = logging.getLogger(__name__)

def get_ckpt_path(model_name: str, scenario: str) -> str | None:
    if model_name == 'ADAPTIVE_RNN':
        override = os.environ.get('ADAPTIVE_RNN_CKPT_PATH', '').strip()
        if override:
            logger.info(f'Using ADAPTIVE_RNN_CKPT_PATH override: {override}')
            return override
    if model_name == 'NP':
        return None
    base_out_dir = Path(DIR_OUTPUTS) / scenario.upper()
    if base_out_dir.exists():
        if model_name == 'ADAPTIVE_RNN':
            preferred_keywords = ['ADAPTIVE_ROUTER_STAGE3']
        elif model_name == 'ALC_RNN':
            preferred_keywords = ['ALC_RNN_STAGE1']
        else:
            preferred_keywords = [model_name]
        matched_dirs = []
        for kw in preferred_keywords:
            current_matches = []
            for d in base_out_dir.iterdir():
                if not d.is_dir():
                    continue
                if kw in ['ADAPTIVE_ROUTER_RECOVER_STAGE35B', 'ADAPTIVE_PREDICTOR_REFINE_STAGE35A', 'ADAPTIVE_JOINT_STAGE35', 'ADAPTIVE_ROUTER_STAGE3', 'ALC_RNN_STAGE1']:
                    if kw in d.name:
                        if model_name == 'ADAPTIVE_RNN' and kw == 'ADAPTIVE_ROUTER_STAGE3':
                            upper_name = d.name.upper()
                            if any((x in upper_name for x in ['NOORACLE', 'NOPEAK', 'NOQOS', 'ABLATION'])):
                                continue
                        current_matches.append(d)
                elif d.name == kw or d.name.startswith(f'{kw}_'):
                    current_matches.append(d)
            if current_matches:
                matched_dirs = current_matches
                logger.info(f"Matched experiment directories for {model_name} using keyword '{kw}': {[x.name for x in matched_dirs]}")
                break
        if matched_dirs:
            latest_time_dir = None
            latest_time = ''
            for exp_dir in matched_dirs:
                for time_dir in exp_dir.iterdir():
                    if time_dir.is_dir() and time_dir.name > latest_time:
                        latest_time = time_dir.name
                        latest_time_dir = time_dir
            if latest_time_dir:
                ckpts_dir = latest_time_dir / 'ckpts'
                if ckpts_dir.exists():
                    ckpts = list(ckpts_dir.glob('*.ckpt'))
                    best_ckpt = None
                    min_val_loss = float('inf')
                    pattern = re.compile('val_loss=([0-9]*\\.?[0-9]+)')
                    for ckpt in ckpts:
                        match = pattern.search(ckpt.name)
                        if match:
                            val_loss = float(match.group(1))
                            if val_loss < min_val_loss:
                                min_val_loss = val_loss
                                best_ckpt = ckpt
                    if best_ckpt:
                        logger.info(f'Auto-discovered BEST checkpoint for {model_name}: {best_ckpt.name}')
                        return str(best_ckpt)
                    elif ckpts:
                        logger.info(f'Auto-discovered fallback checkpoint for {model_name}: {ckpts[-1].name}')
                        return str(ckpts[-1])
    legacy_path = Path(DIR_WEIGHTS) / scenario.lower() / model_name.lower() / 'model.ckpt'
    if legacy_path.exists():
        return str(legacy_path)
    raise FileNotFoundError(f"\n[Error] Could not find any checkpoint for '{model_name}' in scenario '{scenario}'.\nChecked outputs/{scenario} with preferred keywords, and also legacy path:\n{legacy_path}")

def _apply_adaptive_eval_config_override(model, model_name: str):
    if model_name != 'ADAPTIVE_RNN':
        return model
    cfg_path = os.environ.get('ADAPTIVE_RNN_EVAL_CONFIG_PATH', '').strip()
    if not cfg_path:
        return model
    cfg_file = Path(cfg_path)
    if not cfg_file.exists():
        raise FileNotFoundError(f'ADAPTIVE_RNN_EVAL_CONFIG_PATH does not exist: {cfg_file}')
    with open(cfg_file, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)
    params = cfg.get('model', {}).get('params', {})
    keys = ['high_ds_gate_boost', 'high_ds_low_penalty', 'high_ds_threshold_ns', 'high_ds_hr_spectral_prior_strength', 'high_ds_hr_spectral_threshold', 'high_ds_hr_spectral_feature_index', 'two_stage_gate_threshold', 'two_stage_gate_threshold_high', 'two_stage_gate_threshold_refresh']
    applied = {}
    for key in keys:
        if key in params and hasattr(model, key):
            old_value = getattr(model, key)
            new_value = params[key]
            if key.endswith('_feature_index'):
                new_value = int(new_value)
            else:
                new_value = float(new_value)
            setattr(model, key, new_value)
            applied[key] = (old_value, new_value)
    if applied:
        logger.info(f'Applied ADAPTIVE_RNN eval config override from: {cfg_file}')
        for key, (old_value, new_value) in applied.items():
            logger.info(f'  {key}: {old_value} -> {new_value}')
    return model

def _get_eval_model(model_name: str, device: torch.device, scenario: str, ckpt_path: str | None=None):
    model_class_name = f'{model_name}_{scenario}'
    model_class = getattr(PREDICTORS, model_class_name)
    model = model_class.load_from_checkpoint(ckpt_path) if 'NP' not in model_class_name else model_class()
    model = _apply_adaptive_eval_config_override(model, model_name=model_name)
    model.to(device)
    model.eval()
    return model

def get_eval_model(model_name: str, device: torch.device, scenario: str):
    ckpt_path = get_ckpt_path(model_name=model_name, scenario=scenario)
    logger.info(f'Loading model {model_name} for scenario {scenario} from checkpoint: {ckpt_path}\n')
    return _get_eval_model(model_name=model_name, device=device, scenario=scenario, ckpt_path=ckpt_path)

def get_eval_model_with_imputer(model_name: str, device: torch.device, scenario: str):
    model = get_eval_model(model_name, device, scenario)
    logger.info(f'Wrapping Lightning model {model_name} with ForwardBackwardImputer for package drop handling\n')
    return LightningModelWithImputer(model)

def wrap_model_with_imputer(model: pl.LightningModule | nn.Module):
    if isinstance(model, pl.LightningModule):
        return LightningModelWithImputer(model)
    else:
        return ModelWithImputer(model)

class ForwardBackwardImputer(nn.Module):

    def __init__(self, atol=1e-06, rtol=0.001):
        super().__init__()
        self.atol = atol
        self.rtol = rtol

    def _impute_missing(self, x):
        zeros = torch.zeros_like(x)
        close_mask = torch.isclose(x, zeros, atol=1e-06, rtol=0.001)
        mask = close_mask.all(dim=-1)
        B, L, _ = x.shape
        device = x.device
        idx = torch.arange(L, device=device).unsqueeze(0).repeat(B, 1)
        idx = torch.where(mask, torch.zeros_like(idx), idx)
        idx_fwd = torch.cummax(idx, dim=1).values
        b = torch.arange(B, device=device).unsqueeze(1).repeat(1, L)
        x_fwd = x[b, idx_fwd]
        still_missing = mask & (idx_fwd == 0)
        if still_missing.any():
            idx_rev = torch.arange(L - 1, -1, -1, device=device).unsqueeze(0).repeat(B, 1)
            mask_rev = mask.flip(dims=[1])
            idx_rev = torch.where(mask_rev, torch.full_like(idx_rev, L - 1), idx_rev)
            idx_bwd = L - 1 - torch.cummax(idx_rev, dim=1).values
            x_bwd = x[b, idx_bwd]
            x_filled = torch.where(still_missing.unsqueeze(-1), x_bwd, x_fwd)
        else:
            x_filled = x_fwd
        return x_filled

    def forward(self, x):
        *batch_dims, L, D = x.shape
        x_flat = x.reshape(-1, L, D)
        x_imp_flat = self._impute_missing(x_flat)
        x_imp = x_imp_flat.reshape(*batch_dims, L, D)
        return x_imp

class ModelWithImputer(nn.Module):

    def __init__(self, base_model: nn.Module):
        super().__init__()
        self.base_model = base_model
        self.imputer = ForwardBackwardImputer(atol=1e-06, rtol=0.001)
        self.name = self.base_model.name
        self.is_separate_antennas = self.base_model.is_separate_antennas

    def forward(self, x, *args, **kwargs):
        if not self.training:
            x = self.imputer(x)
        return self.base_model(x, *args, **kwargs)

class LightningModelWithImputer(nn.Module):

    def __init__(self, lightning_model):
        super().__init__()
        self.lightning_model = lightning_model
        self.imputer = ForwardBackwardImputer(atol=1e-06, rtol=0.001)
        self.name = self.lightning_model.name
        self.is_separate_antennas = self.lightning_model.is_separate_antennas
        self.lightning_model.eval()

    def forward(self, x, *args, **kwargs):
        if not self.training:
            x = self.imputer(x)
        with torch.no_grad():
            return self.lightning_model(x, *args, **kwargs)

    def to(self, device):
        self.lightning_model.to(device)
        self.imputer.to(device)
        return super().to(device)

    def eval(self):
        self.lightning_model.eval()
        return super().eval()

    def train(self, mode=True):
        if mode:
            logger.warning('LightningModelWithImputer is designed for inference only. Lightning model remains in eval mode.')
        self.imputer.train(mode)
        return super().train(mode)
