from src.noise.noise_testing import Noise
from src.testing.config import BATCH_SIZE, JOBS_PER_MODEL, LIST_MODELS, LIST_SCENARIOS, create_all_combinations, log_gpu_memory_usage, slice_combinations

def get_array_mapping(array_id):
    total_models = len(LIST_MODELS)
    max_array_id = total_models * JOBS_PER_MODEL
    if not 1 <= array_id <= max_array_id:
        raise ValueError(f'Array ID {array_id} is out of range. Valid range: 1-{max_array_id}')
    array_idx = array_id - 1
    model_idx = array_idx // JOBS_PER_MODEL
    model_name = LIST_MODELS[model_idx]
    slice_idx = array_idx % JOBS_PER_MODEL
    slice_info = (slice_idx, JOBS_PER_MODEL)
    return (model_name, slice_info)
if __name__ == '__main__':
    import argparse
    import gc
    import os
    from pathlib import Path
    import torch
    from tqdm import tqdm
    from src.cp.loss.loss import MSELoss, NMSELoss, SELoss
    from src.testing.get_models import get_eval_model, wrap_model_with_imputer
    from src.testing.prediction_performance.test_unit import test_unit
    from src.utils.dirs import DIR_DATA, DIR_OUTPUTS
    from src.utils.main_utils import make_logger
    from src.utils.time_utils import get_current_time
    parser = argparse.ArgumentParser(description='Run prediction performance testing')
    parser.add_argument('--model', '-m', type=str, help='Specific model to test (if not provided, uses SLURM array mode)')
    args = parser.parse_args()
    if args.model:
        model_name = args.model
        if model_name not in LIST_MODELS:
            raise ValueError(f'Model {model_name} not found in LIST_MODELS: {LIST_MODELS}')
        slice_info = None
        mode = 'local'
    else:
        array_id = int(os.environ.get('SLURM_ARRAY_TASK_ID', '1'))
        model_name, slice_info = get_array_mapping(array_id)
        mode = 'cluster'
    dir_outputs = Path(DIR_OUTPUTS) / 'testing' / 'prediction_performance'
    cur_time = get_current_time()
    if mode == 'local':
        dir_outputs = dir_outputs / f'{model_name}' / 'full_test' / cur_time
    else:
        assert slice_info is not None, 'slice_info should not be None in cluster mode'
        dir_outputs = dir_outputs / f'{model_name}' / f'slice_{slice_info[0] + 1}' / cur_time
    dir_outputs.mkdir(parents=True, exist_ok=True)
    df_path = dir_outputs / 'result.csv'
    logger = make_logger(dir_outputs)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if torch.cuda.is_available():
        device_name = torch.cuda.get_device_name(0)
    logger.info('device - {} | {}'.format(device, device_name if torch.cuda.is_available() else 'CPU'))
    if mode == 'local':
        logger.info(f'Running in local mode - model: {model_name} (full test, no slicing)')
    else:
        assert slice_info is not None, 'slice_info should not be None in cluster mode'
        logger.info(f'Running in cluster mode - Array ID {array_id}: model: {model_name}, slice: {slice_info[0] + 1} of {slice_info[1]} total jobs')
    criterion_nmse = NMSELoss().to(device)
    logger.info('NMSE loss function initialized')
    criterion_mse = MSELoss().to(device)
    logger.info('MSE loss function initialized')
    criterion_se = SELoss(SNR=10).to(device)
    logger.info('SE loss function initialized')
    noise = Noise()
    list_all_combs = create_all_combinations()
    if mode == 'local':
        list_assigned_combs = list_all_combs
        tot_combs = len(list_assigned_combs)
        logger.info(f'Processing all {tot_combs} combinations for {model_name} (local mode)')
    else:
        list_assigned_combs = slice_combinations(list_all_combs, slice_info)
        tot_combs = len(list_assigned_combs)
        tot_all_combs = len(list_all_combs)
        logger.info(f'Processing {tot_combs} out of {tot_all_combs} total combinations for {model_name} (cluster mode)')
    logger.info('Loading required models and keeping on CPU...')
    cpu_device = torch.device('cpu')
    models = {}
    models_imputer = {}
    if 'TDD' in LIST_SCENARIOS:
        models['TDD'] = get_eval_model(model_name=model_name, device=device, scenario='TDD').to(cpu_device)
        models_imputer['TDD'] = wrap_model_with_imputer(models['TDD']).to(cpu_device)
    if 'FDD' in LIST_SCENARIOS:
        models['FDD'] = get_eval_model(model_name=model_name, device=device, scenario='FDD').to(cpu_device)
        models_imputer['FDD'] = wrap_model_with_imputer(models['FDD']).to(cpu_device)
    logger.info(f'Successfully loaded models for scenarios: {LIST_SCENARIOS}')
    log_gpu_memory_usage(logger)
    list_assigned_combs.sort(key=lambda x: (x[0], x[2]))
    for scenario, is_gen, noise_type, nd, cm, ds, ms in tqdm(list_assigned_combs, total=tot_combs, desc=f'Testing assigned combinations | {model_name}'):
        assert isinstance(nd, (int, float))
        assert isinstance(cm, str)
        assert isinstance(ds, float)
        assert isinstance(ms, int)
        if noise_type == 'packagedrop':
            current_model = models_imputer[scenario]
        else:
            current_model = models[scenario]
        current_model.to(device)
        current_model.eval()
        is_U2D = scenario == 'FDD'
        df = test_unit(scenario=scenario, is_gen=is_gen, is_U2D=is_U2D, dir_data=Path(DIR_DATA), batch_size=BATCH_SIZE, device=device, list_models=[current_model], criterion_nmse=criterion_nmse, criterion_mse=criterion_mse, criterion_se=criterion_se, cm=cm, ds=ds, ms=ms, noise_type=noise_type, noise_func=getattr(noise, noise_type), noise_degree=nd, df_path=df_path)
        current_model.cpu()
        torch.cuda.empty_cache() if torch.cuda.is_available() else None
    models.clear()
    models_imputer.clear()
    logger.info(f'Cleaned up all models for {LIST_SCENARIOS}')
    torch.cuda.empty_cache() if torch.cuda.is_available() else None
    gc.collect()
    logger.info(f'Completed memory cleanup for model: {model_name}')
    log_gpu_memory_usage(logger)
    logger.info(f'Testing completed successfully for {model_name} in {mode} mode')
