from collections.abc import Callable
import gc
import logging
from pathlib import Path
import lightning.pytorch as pl
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from src.utils.data_utils import CSIDataset, collect_fn_gather_antennas, collect_fn_separate_antennas, load_data
from src.utils.norm_utils import denormalize_output, normalize_input
try:
    from src.cp.dataset.data_module import CM_TO_ID
except Exception:
    CM_TO_ID = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4}
logger = logging.getLogger(__name__)

def _append_metrics(store: dict, key: str, pred: torch.Tensor, target: torch.Tensor, criterion_nmse: nn.Module, criterion_mse: nn.Module, criterion_se: nn.Module, is_U2D: bool) -> None:
    pred_orig, target_orig = denormalize_output(pred, target, is_U2D=is_U2D)
    nmse = criterion_nmse(pred_orig, target_orig, by_step=True)
    mse = criterion_mse(pred_orig, target_orig, by_step=True)
    se, se0 = criterion_se(pred_orig, target_orig, by_step=True)
    store[key]['nmse'].append(nmse.detach().cpu().numpy().flatten())
    store[key]['mse'].append(mse.detach().cpu().numpy().flatten())
    store[key]['se'].append(se.detach().cpu().numpy().flatten())
    store[key]['se0'].append(se0.detach().cpu().numpy().flatten())

def _build_record(model_name: str, metric_bucket: dict, cm: str, ds: float, ms: int, is_gen: bool, is_U2D: bool, scenario: str, noise_type: str, noise_degree: int | float) -> dict:
    nmse_mean = np.mean(metric_bucket['nmse'], axis=0)
    mse_mean = np.mean(metric_bucket['mse'], axis=0)
    se_mean = np.mean(metric_bucket['se'], axis=0)
    se0_mean = np.mean(metric_bucket['se0'], axis=0)
    nmse_std = np.std(metric_bucket['nmse'], axis=0)
    mse_std = np.std(metric_bucket['mse'], axis=0)
    se_std = np.std(metric_bucket['se'], axis=0)
    se0_std = np.std(metric_bucket['se0'], axis=0)
    return {'model': model_name, 'cm': cm, 'ds': ds, 'ms': ms, 'is_gen': is_gen, 'is_U2D': is_U2D, 'scenario': scenario, 'noise_type': noise_type, 'noise_degree': noise_degree, 'nmse_mean': nmse_mean, 'nmse_std': nmse_std, 'mse_mean': mse_mean, 'mse_std': mse_std, 'se_mean': se_mean, 'se_std': se_std, 'se0_mean': se0_mean, 'se0_std': se0_std}

def _get_rate_values_from_model(model) -> torch.Tensor:
    if hasattr(model, 'lightning_model'):
        lm = model.lightning_model
        if hasattr(lm, 'rate_values'):
            return lm.rate_values.detach().cpu().float()
    if hasattr(model, 'rate_values'):
        return model.rate_values.detach().cpu().float()
    return torch.tensor([0.0, 32.0, 128.0, 256.0], dtype=torch.float32)

def _build_adaptive_meta(cm: str, ds: float, ms: int) -> dict:
    cm_key = str(cm).upper()
    cm_id = CM_TO_ID.get(cm_key, 0)
    return {'cm_id': torch.tensor(cm_id, dtype=torch.long), 'ds_ns': torch.tensor(float(ds) * 1000000000.0, dtype=torch.float32), 'ds': torch.tensor(float(ds), dtype=torch.float32), 'ms': torch.tensor(int(ms), dtype=torch.float32)}

def test_unit(scenario: str, is_gen: bool, is_U2D: bool, dir_data: Path, batch_size: int, device: torch.device, list_models: list[pl.LightningModule | nn.Module], criterion_nmse: nn.Module, criterion_mse: nn.Module, criterion_se: nn.Module, cm: str, ds: float, ms: int, noise_type: str, noise_func: Callable, noise_degree: int | float, df_path: Path | str):
    h_hist = load_data(dir_data=dir_data, list_cm=[cm], list_ds=[ds], list_ms=[ms], is_train=False, is_gen=is_gen, is_hist=True, is_U2D=is_U2D)
    h_pred = load_data(dir_data=dir_data, list_cm=[cm], list_ds=[ds], list_ms=[ms], is_train=False, is_gen=is_gen, is_hist=False, is_U2D=is_U2D)
    h_hist, h_pred = normalize_input(h_hist, h_pred, is_U2D=is_U2D)
    if noise_type == 'vanilla':
        for i in range(len(h_hist)):
            h_hist[i] = h_hist[i] + noise_func(h_hist[i], noise_degree)
    else:
        h_hist = h_hist + noise_func(h_hist, noise_degree)
    test_dataset = CSIDataset(h_hist, h_pred)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0, collate_fn=collect_fn_gather_antennas)
    test_dataloader_separate_antennas = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0, collate_fn=collect_fn_separate_antennas)
    list_records = []
    for model in list_models:
        model_name = getattr(model, 'name', model.__class__.__name__)
        is_adaptive = 'ADAPTIVE' in str(model_name).upper()
        metric_store = {}
        if is_adaptive:
            metric_store['ADAPTIVE_RNN_BASE'] = {'nmse': [], 'mse': [], 'se': [], 'se0': []}
            metric_store['ADAPTIVE_RNN_FINAL'] = {'nmse': [], 'mse': [], 'se': [], 'se0': []}
            action_store = {'avg_budget': [], 'skip_ratio': [], 'low_ratio': [], 'high_ratio': [], 'refresh_ratio': [], 'high_refresh_ratio': []}
            rate_values = _get_rate_values_from_model(model)
        else:
            metric_store[model_name] = {'nmse': [], 'mse': [], 'se': [], 'se0': []}
        dataloader = test_dataloader_separate_antennas if model.is_separate_antennas else test_dataloader
        adaptive_meta = _build_adaptive_meta(cm=cm, ds=ds, ms=ms)
        for hist, target in dataloader:
            hist, target = (hist.to(device), target.to(device))
            if is_adaptive:
                batch_dict = {'hist': hist, 'target': target, 'cm_id': adaptive_meta['cm_id'].to(device), 'ds_ns': adaptive_meta['ds_ns'].to(device), 'ds': adaptive_meta['ds'].to(device), 'ms': adaptive_meta['ms'].to(device)}
                if hasattr(model, 'lightning_model'):
                    hist_input = hist
                    if hasattr(model, 'imputer'):
                        hist_input = model.imputer(hist)
                    batch_dict['hist'] = hist_input
                    pred_out = model.lightning_model.predict_step(batch_dict, batch_idx=0)
                else:
                    pred_out = model.predict_step(batch_dict, batch_idx=0)
                if not isinstance(pred_out, dict):
                    raise TypeError(f'Adaptive model {model_name} should return dict, got {type(pred_out)}')
                pred_base = pred_out.get('pred_base', None)
                pred_final = pred_out.get('final_hat', None)
                if pred_base is None:
                    raise KeyError(f"Adaptive model {model_name} output missing 'pred_base'")
                if pred_final is None:
                    raise KeyError(f"Adaptive model {model_name} output missing 'final_hat'")
                _append_metrics(metric_store, 'ADAPTIVE_RNN_BASE', pred_base, target, criterion_nmse, criterion_mse, criterion_se, is_U2D)
                _append_metrics(metric_store, 'ADAPTIVE_RNN_FINAL', pred_final, target, criterion_nmse, criterion_mse, criterion_se, is_U2D)
                action_probs = pred_out.get('action_probs', None)
                action_idx = pred_out.get('action_idx', None)
                if action_probs is not None:
                    ap = action_probs.detach().cpu().float()
                    exp_budget = (ap * rate_values.view(1, 1, -1)).sum(dim=-1)
                    action_store['avg_budget'].append(exp_budget.mean().item())
                    action_store['skip_ratio'].append(ap[..., 0].mean().item())
                    action_store['low_ratio'].append(ap[..., 1].mean().item())
                    action_store['high_ratio'].append(ap[..., 2].mean().item())
                    action_store['refresh_ratio'].append(ap[..., 3].mean().item())
                    action_store['high_refresh_ratio'].append((ap[..., 2] + ap[..., 3]).mean().item())
                elif action_idx is not None:
                    ai = action_idx.detach().cpu().numpy()
                    rv = rate_values.numpy()
                    action_store['avg_budget'].append(float(np.mean(rv[ai])))
                    action_store['skip_ratio'].append(float((ai == 0).mean()))
                    action_store['low_ratio'].append(float((ai == 1).mean()))
                    action_store['high_ratio'].append(float((ai == 2).mean()))
                    action_store['refresh_ratio'].append(float((ai == 3).mean()))
                    action_store['high_refresh_ratio'].append(float(((ai == 2) | (ai == 3)).mean()))
            else:
                pred_out = model(hist)
                pred = pred_out['final_hat'] if isinstance(pred_out, dict) else pred_out
                _append_metrics(metric_store, model_name, pred, target, criterion_nmse, criterion_mse, criterion_se, is_U2D)
        for record_model_name, bucket in metric_store.items():
            record = _build_record(model_name=record_model_name, metric_bucket=bucket, cm=cm, ds=ds, ms=ms, is_gen=is_gen, is_U2D=is_U2D, scenario=scenario, noise_type=noise_type, noise_degree=noise_degree)
            if is_adaptive and record_model_name == 'ADAPTIVE_RNN_FINAL':
                record['avg_budget'] = float(np.mean(action_store['avg_budget'])) if action_store['avg_budget'] else np.nan
                record['skip_ratio'] = float(np.mean(action_store['skip_ratio'])) if action_store['skip_ratio'] else np.nan
                record['low_ratio'] = float(np.mean(action_store['low_ratio'])) if action_store['low_ratio'] else np.nan
                record['high_ratio'] = float(np.mean(action_store['high_ratio'])) if action_store['high_ratio'] else np.nan
                record['refresh_ratio'] = float(np.mean(action_store['refresh_ratio'])) if action_store['refresh_ratio'] else np.nan
                record['high_refresh_ratio'] = float(np.mean(action_store['high_refresh_ratio'])) if action_store['high_refresh_ratio'] else np.nan
            list_records.append(record)
    if isinstance(df_path, str):
        df_path = Path(df_path)
    try:
        df = pd.read_csv(df_path)
    except FileNotFoundError:
        df = pd.DataFrame()
    df_new = pd.DataFrame(list_records)
    df = pd.concat([df, df_new], ignore_index=True)
    df.to_csv(df_path, index=False)
    del h_hist, h_pred
    del test_dataset, test_dataloader, test_dataloader_separate_antennas
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()
    return df_new
