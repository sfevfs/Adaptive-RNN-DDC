from itertools import product
import logging
from pathlib import Path
import torch
from torch.utils.data import Dataset
logger = logging.getLogger(__name__)
CSI_PERIODICITY = 5
NUM_OFDM_SYMBOLS = 14
CARRIER_FREQUENCY = 2400000000.0
SUBCARRIER_SPACING = 30000.0
BATCH_SIZE = 10
BATCH_SIZE_DEBUG = 2
NUM_REPEAT_TRAIN = 1000
NUM_REPEAT_TRAIN_DEBUG = 2
NUM_REPEAT_TEST = 100
NUM_REPEAT_TEST_DEBUG = 2
HIST_LEN = 16
PRED_LEN = 4
TOT_LEN = HIST_LEN + PRED_LEN
NUM_SUBCARRIERS = 300
NUM_GAP_SUBCARRIERS = 150
TOT_SUBCARRIERS = NUM_SUBCARRIERS * 2 + NUM_GAP_SUBCARRIERS
NUM_BS_ANT_ROW = 4
NUM_BS_ANT_COL = 4
NUM_DUPLEX = 2
TOT_ANTENNAS = NUM_BS_ANT_ROW * NUM_BS_ANT_COL * NUM_DUPLEX
NUM_UT_ANT = 1
LIST_CHANNEL_MODEL = ['A', 'C', 'D']
LIST_DELAY_SPREAD = [3e-08, 1e-07, 3e-07]
LIST_MIN_SPEED_TRAIN = [1, 10, 30]
LIST_MIN_SPEED_TEST = [1, 10, 30]
SNR_RANGE_GAUSSIAN_NOISE_TRAIN = (0, 25)
LIST_CHANNEL_MODEL_GEN = ['A', 'B', 'C', 'D', 'E']
LIST_DELAY_SPREAD_GEN = [3e-08, 5e-08, 1e-07, 2e-07, 3e-07, 4e-07]
LIST_MIN_SPEED_TEST_GEN = sorted([*range(3, 46, 3), 1, 10])

def make_folder_name(cm: str, ds: float, ms: int, **kwargs) -> str:
    ds = round(ds * 1000000000.0)
    ds_str = str(ds).zfill(3)
    ms_str = str(ms)
    ms_str = ms_str.zfill(3)
    return f'cm_{cm}_ds_{ds_str}_ms_{ms_str}'

def _load_data(dir_data: Path, cm: str, ds: float, ms: int, is_train: bool=True, is_gen: bool=False, is_hist: bool=True, is_U2D: bool=False, num_load: int=-1) -> torch.Tensor:
    assert not (is_train and is_gen), 'generalization is only for test mode'
    file_name = 'H_U_hist.pt' if is_hist else 'H_D_pred.pt' if is_U2D else 'H_U_pred.pt'
    folder_name = make_folder_name(cm, ds, ms)
    if is_train:
        dir_folder = dir_data / 'train' / 'regular' / folder_name
        path_file = dir_folder / file_name
    else:
        if is_gen:
            dir_folder = dir_data / 'test' / 'generalization' / folder_name
        else:
            dir_folder = dir_data / 'test' / 'regular' / folder_name
        path_file = dir_folder / file_name
    data = torch.load(path_file, weights_only=True)
    if num_load > 0:
        data = data[:num_load]
    return data

def load_data(dir_data: Path, list_cm: list[str], list_ds: list[float], list_ms: list[int], is_train: bool=True, is_gen: bool=False, is_hist: bool=True, is_U2D: bool=False, num_load: int=-1) -> torch.Tensor:
    assert not (is_train and is_gen), 'generalization is only for test mode'
    data = []
    for cm, ds, ms in product(list_cm, list_ds, list_ms):
        data.append(_load_data(dir_data=dir_data, cm=cm, ds=ds, ms=ms, is_train=is_train, is_gen=is_gen, is_hist=is_hist, is_U2D=is_U2D, num_load=num_load))
    data = torch.cat(data, dim=0)
    return data

class CSIDataset(Dataset):

    def __init__(self, H_hist, H_pred):
        super().__init__()
        self.H_hist = H_hist
        self.H_pred = H_pred

    def __len__(self):
        return len(self.H_hist)

    def __getitem__(self, idx):
        hist = self.H_hist[idx]
        pred = self.H_pred[idx]
        return (hist, pred)

def collect_fn_separate_antennas(batch):
    list_hist, list_pred = zip(*batch, strict=False)
    hist = torch.stack(list_hist, dim=0)
    pred = torch.stack(list_pred, dim=0)
    hist = hist.view(-1, hist.shape[2], hist.shape[3])
    pred = pred.view(-1, pred.shape[2], pred.shape[3])
    hist = torch.view_as_real(hist)
    pred = torch.view_as_real(pred)
    hist = hist.view(hist.shape[0], hist.shape[1], -1)
    pred = pred.view(pred.shape[0], pred.shape[1], -1)
    return (hist, pred)

def collect_fn_gather_antennas(batch):
    list_hist, list_pred = zip(*batch, strict=False)
    hist = torch.stack(list_hist, dim=0)
    pred = torch.stack(list_pred, dim=0)
    return (hist, pred)
