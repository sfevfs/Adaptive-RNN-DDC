DIR_STORAGE = 'z_artifacts'
DIR_DATA = DIR_STORAGE + '/data'
DIR_OUTPUTS = DIR_STORAGE + '/outputs'
DIR_WEIGHTS = DIR_STORAGE + '/weights'
