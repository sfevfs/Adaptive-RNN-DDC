import inspect
import logging
from pathlib import Path
import re
import lightning.pytorch as pl
import torch
from src.cp.config.config import ExperimentConfig
from src.cp.models import PREDICTORS
logger = logging.getLogger(__name__)

def _best_ckpt_path(ckpt_dir: Path) -> Path:
    all_ckpts = list(ckpt_dir.glob('*.ckpt'))
    if not all_ckpts:
        raise FileNotFoundError(f'No .ckpt files found in {ckpt_dir!r}')
    ckpt_pairs = []
    pattern = re.compile('val_loss=([0-9]*\\.?[0-9]+)')
    for checkpoint_path in all_ckpts:
        match = pattern.search(checkpoint_path.stem)
        if match:
            val_loss_value = float(match.group(1))
            ckpt_pairs.append((val_loss_value, checkpoint_path))
        else:
            logger.debug(f'Skipping checkpoint file with unexpected name: {checkpoint_path.name}')
    if not ckpt_pairs:
        raise FileNotFoundError(f"No checkpoint filenames in {ckpt_dir!r} match the expected pattern '*val_loss=XXX*.ckpt'")
    best_val, best_checkpoint_path = min(ckpt_pairs, key=lambda tup: tup[0])
    logger.info(f'Selected best checkpoint: {best_checkpoint_path.name} with val_loss={best_val:.6f}')
    return best_checkpoint_path

def _init_model_fresh(model_class, config: ExperimentConfig) -> pl.LightningModule:
    try:
        model = model_class(config)
        logger.info('Initialized new model with constructor signature model_class(config)')
        return model
    except TypeError as e:
        logger.warning(f'model_class(config) failed for {model_class.__name__}: {e}. Trying model_class() fallback.')
    try:
        model = model_class()
        logger.info('Initialized new model with constructor signature model_class()')
        return model
    except TypeError as e:
        raise TypeError(f'Failed to initialize model {model_class.__name__}. Tried both model_class(config) and model_class(). Last error: {e}') from e

def _load_model_from_ckpt(model_class, checkpoint_to_load: Path, config: ExperimentConfig, device: torch.device) -> pl.LightningModule:
    ckpt_path_str = str(checkpoint_to_load)
    try:
        model = model_class.load_from_checkpoint(checkpoint_path=ckpt_path_str, config=config, map_location=device)
        logger.info(f'Loaded checkpoint with explicit config for model {model_class.__name__}: {checkpoint_to_load.name}')
        return model
    except TypeError as e:
        logger.warning(f'load_from_checkpoint(..., config=config) failed for {model_class.__name__}: {e}. Trying fallback without config.')
    try:
        model = model_class.load_from_checkpoint(checkpoint_path=ckpt_path_str, map_location=device)
        logger.info(f'Loaded checkpoint without explicit config for model {model_class.__name__}: {checkpoint_to_load.name}')
        return model
    except TypeError as e:
        raise TypeError(f'Failed to load checkpoint for model {model_class.__name__}. Tried both with and without config. Last error: {e}') from e

def load_model(config: ExperimentConfig, device: torch.device) -> pl.LightningModule:
    model_cfg = config.model
    if not hasattr(PREDICTORS, model_cfg.name):
        available = [k for k in dir(PREDICTORS) if not k.startswith('_')]
        raise AttributeError(f"Model '{model_cfg.name}' not found in PREDICTORS registry. Available models: {available}")
    model_class = getattr(PREDICTORS, model_cfg.name)
    logger.info(f'Using model class: {model_class.__name__}')
    if model_cfg.checkpoint_path is not None:
        ckpt_path = Path(model_cfg.checkpoint_path)
        if ckpt_path.is_file() and ckpt_path.suffix == '.ckpt':
            checkpoint_to_load = ckpt_path
            logger.info(f'Loading from specific checkpoint: {checkpoint_to_load}')
        elif ckpt_path.is_dir():
            checkpoint_to_load = _best_ckpt_path(ckpt_path)
            logger.info(f'Auto-selected best checkpoint from directory: {checkpoint_to_load}')
        else:
            raise FileNotFoundError(f"Checkpoint path '{model_cfg.checkpoint_path}' is not a valid file or directory")
        model = _load_model_from_ckpt(model_class=model_class, checkpoint_to_load=checkpoint_to_load, config=config, device=device)
        logger.info(f'Successfully restored model from checkpoint: {checkpoint_to_load.name}')
    else:
        model = _init_model_fresh(model_class, config)
        logger.info('Initialized new model from configuration (no checkpoint provided)')
    model.to(device)
    logger.info(f'Model moved to device: {device}')
    return model
