from einops import rearrange
import torch

def real_flat_to_complex(x: torch.Tensor) -> torch.Tensor:
    x_pair = rearrange(x, 'b l (k o) -> b l k o', o=2)
    return torch.complex(x_pair[..., 0], x_pair[..., 1])

def complex_to_real_flat(x_complex: torch.Tensor) -> torch.Tensor:
    x_pair = torch.view_as_real(x_complex)
    return rearrange(x_pair, 'b l k o -> b l (k o)')
