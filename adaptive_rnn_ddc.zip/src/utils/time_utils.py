import datetime
from pathlib import Path
TIME_FORMAT = '%Y%m%d_%H%M%S'

def get_current_time():
    return datetime.datetime.now().strftime(TIME_FORMAT)

def get_latest_datetime_folder(parent_dir: Path) -> Path | None:
    if not parent_dir.exists():
        return None
    datetime_folders = []
    for folder in parent_dir.iterdir():
        if folder.is_dir():
            try:
                datetime.datetime.strptime(folder.name, TIME_FORMAT)
                datetime_folders.append(folder)
            except ValueError:
                continue
    if not datetime_folders:
        return None
    datetime_folders.sort(key=lambda p: datetime.datetime.strptime(p.name, TIME_FORMAT), reverse=True)
    return datetime_folders[0]
